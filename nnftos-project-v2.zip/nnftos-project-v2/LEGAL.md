# NNFTOS - No Name For This OS

## License Information

This distribution contains software under various licenses. See below for details.

### Core Components

| Component | License | License File |
|-----------|---------|--------------|
| Linux Kernel | GPL-2.0-only | /LICENSES/GPL-2.0.txt |
| systemd | LGPL-2.1-or-later | /LICENSES/LGPL-2.1.txt |
| GRUB | GPL-3.0-or-later | /LICENSES/GPL-3.0.txt |
| Roboto Font | Apache-2.0 | /LICENSES/Roboto-License.txt |

### Full License Texts

All license texts are available in the `/LICENSES/` directory:
- `GPL-2.0.txt` - GNU General Public License v2
- `GPL-3.0.txt` - GNU General Public License v3
- `LGPL-2.1.txt` - GNU Lesser General Public License v2.1
- `Apache-2.0.txt` - Apache License 2.0
- `MIT.txt` - MIT License
- `Roboto-License.txt` - Roboto Font License

### Source Code

For GPL/LGPL licensed components, source code is available upon request.

**Contact:** olivierkenzo71@gmail.com

See `/OFFER_OF_SOURCE.txt` for complete details.

### Copyright

Individual package copyright information is preserved in:
`/usr/share/doc/*/copyright`

---

**NNFTOS Version:** 1.0
**Last Updated:** 2025
