# NNFTOS Environment Configuration
# This file is sourced by all users

# Set default editor
export EDITOR=nano
export VISUAL=nano

# Set pager
export PAGER=less

# Set locale if not already set
if [ -z "$LANG" ]; then
    export LANG=en_US.UTF-8
    export LC_ALL=en_US.UTF-8
fi

# Set PATH
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games"

# Set terminal type
if [ -z "$TERM" ]; then
    export TERM=linux
fi

# NNFTOS identification
export NNFTOS_VERSION="1.0"
export NNFTOS_NAME="No Name For This OS"
