#!/bin/bash
#
# NNFTOS - No Name For This OS
# Main Build Script
#
# This script builds the complete NNFTOS ISO for both architectures
#
# License: GPL-2.0
# Contact: olivierkenzo71@gmail.com
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Build configuration
UBUNTU_BASE_ARM64="https://cdimage.ubuntu.com/ubuntu-base/releases/26.04/snapshot-4/ubuntu-base-26.04-snapshot4-base-arm64.tar.gz"
UBUNTU_BASE_AMD64="https://cdimage.ubuntu.com/ubuntu-base/releases/26.04/snapshot-4/ubuntu-base-26.04-snapshot4-base-amd64.tar.gz"
KERNEL_VERSION="7.0-rc3"
KERNEL_URL="https://git.kernel.org/torvalds/t/linux-${KERNEL_VERSION}.tar.gz"

# Output directory
OUTPUT_DIR="${PROJECT_ROOT}/output"
BUILD_DIR="${PROJECT_ROOT}/build"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_dependencies() {
    log_info "Checking build dependencies..."
    
    local missing_deps=()
    
    # Check for required tools
    for cmd in debootstrap mksquashfs xorriso grub-mkimage wget; do
        if ! command -v "$cmd" &> /dev/null; then
            missing_deps+=("$cmd")
        fi
    done
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        log_warning "Missing dependencies: ${missing_deps[*]}"
        log_info "Installing dependencies..."
        
        sudo apt-get update
        sudo apt-get install -y \
            debootstrap squashfs-tools xorriso mtools \
            syslinux syslinux-common grub-efi-amd64-bin grub-efi-arm64-bin \
            qemu-user-static binfmt-support build-essential \
            libncurses-dev bison flex libssl-dev libelf-dev bc \
            gcc-aarch64-linux-gnu g++-aarch64-linux-gnu \
            wget curl cpio
    fi
    
    log_success "All dependencies satisfied"
}

download_ubuntu_base() {
    local arch=$1
    local url=""
    local output=""

    case $arch in
        arm64)
            url=$UBUNTU_BASE_ARM64
            output="${BUILD_DIR}/ubuntu-base-arm64.tar.gz"
            ;;
        amd64|x86_64)
            url=$UBUNTU_BASE_AMD64
            output="${BUILD_DIR}/ubuntu-base-amd64.tar.gz"
            ;;
        *)
            log_error "Unknown architecture: $arch"
            exit 1
            ;;
    esac

    if [ -f "$output" ]; then
        log_info "Ubuntu base already downloaded for $arch"
        return
    fi

    log_info "Downloading Ubuntu base for $arch..."
    mkdir -p "${BUILD_DIR}"
    wget -c "$url" -O "$output"
    log_success "Downloaded Ubuntu base for $arch"
}

download_kernel() {
    local output="${BUILD_DIR}/linux-${KERNEL_VERSION}.tar.gz"

    if [ -f "$output" ]; then
        log_info "Kernel source already downloaded"
        return
    fi

    log_info "Downloading Linux kernel ${KERNEL_VERSION}..."
    mkdir -p "${BUILD_DIR}"
    wget -c "$KERNEL_URL" -O "$output"
    log_success "Downloaded kernel source"
}

build_kernel() {
    local arch=$1
    local kernel_dir="${BUILD_DIR}/linux-${KERNEL_VERSION}"
    local output_dir="${BUILD_DIR}/kernel-${arch}"

    log_info "Building kernel for $arch..."

    # Extract kernel if not already extracted
    if [ ! -d "$kernel_dir" ]; then
        log_info "Extracting kernel source..."
        tar -xzf "${BUILD_DIR}/linux-${KERNEL_VERSION}.tar.gz" -C "${BUILD_DIR}"
    fi

    cd "$kernel_dir"

    # Set architecture-specific variables
    case $arch in
        arm64)
            export ARCH=arm64
            export CROSS_COMPILE=aarch64-linux-gnu-
            ;;
        amd64|x86_64)
            export ARCH=x86_64
            export CROSS_COMPILE=
            ;;
    esac

    # Clean previous build
    make mrproper

    # Use config from project or create default
    if [ -f "${PROJECT_ROOT}/configs/kernel/${arch}-defconfig" ]; then
        cp "${PROJECT_ROOT}/configs/kernel/${arch}-defconfig" .config
        make olddefconfig
    else
        make defconfig
    fi

    # Enable required features for NNFTOS
    log_info "Enabling kernel features..."
    ./scripts/config --enable CONFIG_DEVTMPFS
    ./scripts/config --enable CONFIG_DEVTMPFS_MOUNT
    ./scripts/config --enable CONFIG_FHANDLE
    ./scripts/config --enable CONFIG_UNIX
    ./scripts/config --enable CONFIG_INET
    ./scripts/config --enable CONFIG_BLK_DEV_INITRD
    ./scripts/config --enable CONFIG_RD_GZIP
    ./scripts/config --enable CONFIG_RD_BZIP2
    ./scripts/config --enable CONFIG_RD_XZ
    ./scripts/config --enable CONFIG_BINFMT_ELF
    ./scripts/config --enable CONFIG_BINFMT_SCRIPT
    ./scripts/config --enable CONFIG_TMPFS
    ./scripts/config --enable CONFIG_PROC_FS
    ./scripts/config --enable CONFIG_SYSFS
    ./scripts/config --enable CONFIG_EFIVAR_FS
    ./scripts/config --enable CONFIG_PARTITION_ADVANCED
    ./scripts/config --enable CONFIG_EFI_PARTITION
    ./scripts/config --enable CONFIG_VIRTIO
    ./scripts/config --enable CONFIG_VIRTIO_PCI
    ./scripts/config --enable CONFIG_VIRTIO_BLK
    ./scripts/config --enable CONFIG_VIRTIO_NET
    ./scripts/config --enable CONFIG_SQUASHFS
    ./scripts/config --enable CONFIG_SQUASHFS_XZ
    ./scripts/config --enable CONFIG_EXT4_FS
    ./scripts/config --enable CONFIG_EFI
    ./scripts/config --enable CONFIG_EFI_STUB
    ./scripts/config --enable CONFIG_MODULES
    ./scripts/config --enable CONFIG_MODULE_UNLOAD

    # Resolve dependencies
    make olddefconfig

    # Build kernel
    log_info "Compiling kernel (this may take a while)..."
    make -j$(nproc)

    # Install kernel to output directory
    mkdir -p "${output_dir}/boot"
    
    if [ "$arch" = "arm64" ]; then
        cp arch/arm64/boot/Image "${output_dir}/boot/vmlinuz-${KERNEL_VERSION}"
    else
        cp arch/x86/boot/bzImage "${output_dir}/boot/vmlinuz-${KERNEL_VERSION}"
    fi

    # Build and install modules
    make modules_install INSTALL_MOD_PATH="${output_dir}"

    # Copy config
    cp .config "${output_dir}/boot/config-${KERNEL_VERSION}"
    cp System.map "${output_dir}/boot/System.map-${KERNEL_VERSION}"

    cd "$PROJECT_ROOT"
    log_success "Kernel built for $arch"
}

prepare_rootfs() {
    local arch=$1
    local rootfs_dir="${BUILD_DIR}/rootfs-${arch}"
    local ubuntu_base=""

    case $arch in
        arm64)
            ubuntu_base="${BUILD_DIR}/ubuntu-base-arm64.tar.gz"
            ;;
        amd64|x86_64)
            ubuntu_base="${BUILD_DIR}/ubuntu-base-amd64.tar.gz"
            ;;
    esac

    log_info "Preparing rootfs for $arch..."

    # Clean and create rootfs directory
    sudo rm -rf "$rootfs_dir"
    mkdir -p "$rootfs_dir"

    # Extract Ubuntu base
    log_info "Extracting Ubuntu base..."
    sudo tar -xzf "$ubuntu_base" -C "$rootfs_dir"

    # Copy QEMU for cross-architecture builds
    if [ "$arch" = "arm64" ]; then
        sudo cp /usr/bin/qemu-aarch64-static "${rootfs_dir}/usr/bin/"
    fi

    # Mount necessary filesystems
    sudo mount --bind /dev "${rootfs_dir}/dev"
    sudo mount --bind /proc "${rootfs_dir}/proc"
    sudo mount --bind /sys "${rootfs_dir}/sys"

    # Copy chroot setup script
    sudo cp "${SCRIPT_DIR}/chroot-setup.sh" "${rootfs_dir}/tmp/"
    sudo chmod +x "${rootfs_dir}/tmp/chroot-setup.sh"

    # Run setup script inside chroot
    log_info "Running chroot setup..."
    sudo chroot "$rootfs_dir" /tmp/chroot-setup.sh

    # Unmount
    sudo umount "${rootfs_dir}/dev" 2>/dev/null || true
    sudo umount "${rootfs_dir}/proc" 2>/dev/null || true
    sudo umount "${rootfs_dir}/sys" 2>/dev/null || true

    # Apply overlay
    log_info "Applying NNFTOS overlay..."
    if [ -d "${PROJECT_ROOT}/rootfs-overlay" ]; then
        sudo cp -a "${PROJECT_ROOT}/rootfs-overlay/"* "${rootfs_dir}/" 2>/dev/null || true
    fi

    # Copy licenses to rootfs
    log_info "Installing license files..."
    sudo cp -r "${PROJECT_ROOT}/LICENSES" "${rootfs_dir}/"
    sudo cp "${PROJECT_ROOT}/COPYING" "${rootfs_dir}/"
    sudo cp "${PROJECT_ROOT}/OFFER_OF_SOURCE.txt" "${rootfs_dir}/"
    sudo cp "${PROJECT_ROOT}/LEGAL.md" "${rootfs_dir}/"

    log_success "Rootfs prepared for $arch"
}

create_initramfs() {
    local arch=$1
    local rootfs_dir="${BUILD_DIR}/rootfs-${arch}"
    local output="${BUILD_DIR}/initramfs-${arch}.cpio.gz"

    log_info "Creating initramfs for $arch..."

    cd "$rootfs_dir"
    
    # Create initramfs
    find . -print0 | cpio --null -ov --format=newc 2>/dev/null | gzip -9 > "$output"

    cd "$PROJECT_ROOT"
    log_success "Created initramfs for $arch"
}

create_iso() {
    local arch=$1
    local iso_dir="${BUILD_DIR}/iso-${arch}"
    local output="${OUTPUT_DIR}/nnftos-${arch}.iso"

    log_info "Creating ISO for $arch..."

    # Clean and create ISO directory structure
    sudo rm -rf "$iso_dir"
    mkdir -p "${iso_dir}/boot/grub"
    mkdir -p "${iso_dir}/live"

    # Copy kernel and initramfs
    cp "${BUILD_DIR}/kernel-${arch}/boot/vmlinuz-${KERNEL_VERSION}" "${iso_dir}/boot/vmlinuz"
    cp "${BUILD_DIR}/initramfs-${arch}.cpio.gz" "${iso_dir}/boot/initramfs.gz"

    # Create squashfs from rootfs
    log_info "Creating squashfs..."
    sudo mksquashfs "${BUILD_DIR}/rootfs-${arch}" "${iso_dir}/live/filesystem.squashfs" -comp xz

    # Copy licenses to ISO root
    cp -r "${PROJECT_ROOT}/LICENSES" "${iso_dir}/"
    cp "${PROJECT_ROOT}/COPYING" "${iso_dir}/"
    cp "${PROJECT_ROOT}/OFFER_OF_SOURCE.txt" "${iso_dir}/"
    cp "${PROJECT_ROOT}/LEGAL.md" "${iso_dir}/"

    # Copy DISCLAIMER and TRADEMARKS if they exist
    if [ -f "${BUILD_DIR}/rootfs-${arch}/DISCLAIMER" ]; then
        cp "${BUILD_DIR}/rootfs-${arch}/DISCLAIMER" "${iso_dir}/"
    fi
    if [ -f "${BUILD_DIR}/rootfs-${arch}/TRADEMARKS" ]; then
        cp "${BUILD_DIR}/rootfs-${arch}/TRADEMARKS" "${iso_dir}/"
    fi

    # Create GRUB config
    cat > "${iso_dir}/boot/grub/grub.cfg" << 'GRUBCFG'
set default=0
set timeout=10

insmod all_video
insmod gfxterm
terminal_output gfxterm

menuentry "No Name For This OS (NNFTOS)" {
    linux /boot/vmlinuz boot=live quiet
    initrd /boot/initramfs.gz
}

menuentry "No Name For This OS (NNFTOS) - Safe Mode" {
    linux /boot/vmlinuz boot=live single
    initrd /boot/initramfs.gz
}

menuentry "No Name For This OS (NNFTOS) - Debug Mode" {
    linux /boot/vmlinuz boot=live debug
    initrd /boot/initramfs.gz
}
GRUBCFG

    # Create GRUB EFI image
    mkdir -p "${iso_dir}/EFI/BOOT"
    
    case $arch in
        arm64)
            grub-mkimage -o "${iso_dir}/EFI/BOOT/BOOTAA64.EFI" -O arm64-efi -p /boot/grub \
                part_gpt part_msdos fat ext2 normal chain boot configfile linux search
            ;;
        amd64|x86_64)
            grub-mkimage -o "${iso_dir}/EFI/BOOT/BOOTX64.EFI" -O x86_64-efi -p /boot/grub \
                part_gpt part_msdos fat ext2 normal chain boot configfile linux search
            ;;
    esac

    # Create ISO
    mkdir -p "${OUTPUT_DIR}"

    xorriso -as mkisofs \
        -V "NNFTOS" \
        -r -J \
        -o "$output" \
        -append_partition 2 0xef "${iso_dir}/EFI/BOOT/BOOTAA64.EFI" 2>/dev/null || \
    xorriso -as mkisofs \
        -V "NNFTOS" \
        -r -J \
        -o "$output" \
        "$iso_dir"

    log_success "ISO created: $output"
}

# Main build function
build_arch() {
    local arch=$1

    log_info "========================================="
    log_info "Building NNFTOS for $arch"
    log_info "========================================="

    download_ubuntu_base "$arch"
    download_kernel
    build_kernel "$arch"
    prepare_rootfs "$arch"
    create_initramfs "$arch"
    create_iso "$arch"

    log_success "========================================="
    log_success "Build complete for $arch"
    log_success "========================================="
}

# Main
main() {
    log_info "NNFTOS Build System"
    log_info "==================="
    log_info ""

    # Check dependencies first
    check_dependencies

    # Create directories
    mkdir -p "${BUILD_DIR}" "${OUTPUT_DIR}"

    # Parse arguments
    if [ $# -eq 0 ]; then
        log_info "Building for both architectures..."
        build_arch "arm64"
        build_arch "amd64"
    else
        case $1 in
            arm64|aarch64)
                build_arch "arm64"
                ;;
            amd64|x86_64|x64)
                build_arch "amd64"
                ;;
            all)
                build_arch "arm64"
                build_arch "amd64"
                ;;
            *)
                log_error "Unknown architecture: $1"
                echo "Usage: $0 [arm64|amd64|all]"
                exit 1
                ;;
        esac
    fi

    log_success "All builds complete!"
    log_info "ISOs available in: ${OUTPUT_DIR}"
}

main "$@"
