#!/bin/bash
#
# NNFTOS Chroot Setup Script
# This script runs inside the chroot to configure the system
#
# License: GPL-2.0
#

set -e

echo "=== NNFTOS Chroot Setup ==="

# Set environment
export DEBIAN_FRONTEND=noninteractive
export DEBCONF_NONINTERACTIVE_SEEN=true

# Update package lists
echo "[1/15] Updating package lists..."
apt-get update

# Install essential packages
echo "[2/15] Installing essential packages..."
apt-get install -y --no-install-recommends \
    systemd \
    systemd-sysv \
    init \
    dbus \
    kmod \
    udev \
    util-linux \
    coreutils \
    bash \
    bash-completion \
    nano \
    vim-tiny \
    less \
    grep \
    sed \
    gawk \
    findutils \
    procps \
    psmisc \
    net-tools \
    iproute2 \
    iputils-ping \
    wget \
    curl \
    ca-certificates \
    apt-utils \
    gnupg \
    libc-bin \
    locales \
    tzdata \
    sudo \
    passwd \
    adduser \
    openssh-client \
    tar \
    gzip \
    bzip2 \
    xz-utils \
    cpio \
    squashfs-tools \
    e2fsprogs \
    dosfstools \
    parted \
    fdisk \
    eudev \
    kbd \
    console-setup \
    console-data \
    fonts-roboto \
    fontconfig \
    neofetch \
    htop \
    tree \
    man-db \
    manpages \
    info

# Remove Ubuntu font family (Canonical IP)
echo "[3/15] Removing Ubuntu font family (Canonical IP)..."
apt-get remove -y fonts-ubuntu 2>/dev/null || true
apt-get autoremove -y

# Configure locale
echo "[4/15] Configuring locale..."
locale-gen en_US.UTF-8
update-locale LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8

# Set hostname
echo "[5/15] Setting hostname..."
echo "nnftos" > /etc/hostname
cat > /etc/hosts << 'EOF'
127.0.0.1   localhost
127.0.1.1   nnftos
::1         localhost ip6-localhost ip6-loopback
ff02::1     ip6-allnodes
ff02::2     ip6-allrouters
EOF

# Configure timezone
echo "[6/15] Configuring timezone..."
ln -sf /usr/share/zoneinfo/UTC /etc/localtime
echo "UTC" > /etc/timezone

# Create default user
echo "[7/15] Creating default user..."
useradd -m -s /bin/bash -G sudo,adm,cdrom,dip,plugdev nnftos 2>/dev/null || true
echo "nnftos:nnftos" | chpasswd
echo "root:root" | chpasswd

# Configure sudo
echo "[8/15] Configuring sudo..."
echo '%sudo ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/sudo-nopasswd
chmod 440 /etc/sudoers.d/sudo-nopasswd

# Clean Ubuntu branding from APT
echo "[9/15] Cleaning Ubuntu branding from APT..."
rm -f /etc/apt/apt.conf.d/50ubuntu-cloudimg 2>/dev/null || true

# Suppress Launchpad branding in APT errors
mkdir -p /etc/apt/apt.conf.d
cat > /etc/apt/apt.conf.d/99no-launchpad-branding << 'EOF'
// Suppress Launchpad branding in APT errors
Acquire::Changelogs::AlwaysOnline "true";
EOF

# Configure sources.list (use generic mirrors, NOT branded)
echo "[10/15] Configuring APT sources..."
cat > /etc/apt/sources.list << 'EOF'
# =============================================================================
# NNFTOS Package Sources
# =============================================================================
# 
# IMPORTANT LEGAL NOTICE:
# ----------------------
# This is NOT Ubuntu. NNFTOS is an independent Linux distribution.
# Packages are sourced from Debian/Ubuntu repositories under their respective
# open source licenses. Ubuntu is a trademark of Canonical Ltd.
# NNFTOS is not affiliated with, endorsed by, or sponsored by Canonical Ltd.
#
# All packages retain their original licenses. See /usr/share/doc/*/copyright
# for individual package licenses.
# =============================================================================

# Main repository (using kernel.org mirror)
deb http://mirrors.kernel.org/ubuntu/ noble main restricted universe multiverse
deb http://mirrors.kernel.org/ubuntu/ noble-updates main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu/ noble-security main restricted universe multiverse
deb http://mirrors.kernel.org/ubuntu/ noble-backports main restricted universe multiverse
EOF

# Configure systemd
echo "[11/15] Configuring systemd..."
systemctl enable systemd-networkd 2>/dev/null || true
systemctl enable systemd-resolved 2>/dev/null || true

# Configure network
echo "[12/15] Configuring network..."
mkdir -p /etc/systemd/network
cat > /etc/systemd/network/20-dhcp.network << 'EOF'
[Match]
Name=eth* en* wlan*

[Network]
DHCP=yes
EOF

# Configure console
echo "[13/15] Configuring console..."
cat > /etc/default/console-setup << 'EOF'
# Console configuration for NNFTOS
ACTIVE_CONSOLES="/dev/tty[1-6]"
CHARMAP="UTF-8"
CODESET="guess"
FONTFACE="Fixed"
FONTSIZE="8x16"
VIDEOMODE=
EOF

# Configure fontconfig to use Roboto
echo "[14/15] Configuring fonts..."
mkdir -p /etc/fonts/conf.avail
mkdir -p /etc/fonts/conf.d

cat > /etc/fonts/local.conf << 'EOF'
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <!-- Default font settings -->
  <match target="pattern">
    <test qual="any" name="family">
      <string>sans-serif</string>
    </test>
    <edit name="family" mode="prepend" binding="strong">
      <string>Roboto</string>
    </edit>
  </match>

  <match target="pattern">
    <test qual="any" name="family">
      <string>monospace</string>
    </test>
    <edit name="family" mode="prepend" binding="strong">
      <string>Roboto Mono</string>
    </edit>
  </match>
</fontconfig>
EOF

# Clean up Ubuntu branding strings
echo "[15/15] Cleaning branding strings..."
find /usr/share -type f -name "*.txt" -exec sed -i 's/Powered by Ubuntu//gi' {} \; 2>/dev/null || true
find /usr/share -type f -name "*.md" -exec sed -i 's/Powered by Ubuntu//gi' {} \; 2>/dev/null || true

# Remove Ubuntu One references
apt-get remove -y ubuntuone-client 2>/dev/null || true
apt-get remove -y ubuntuone-control-panel 2>/dev/null || true
apt-get autoremove -y

# Clean package cache
echo "Cleaning package cache..."
apt-get clean
rm -rf /var/lib/apt/lists/*
rm -rf /tmp/*

# IMPORTANT: Keep copyright files (required by GPL and Debian Policy)
echo "Preserving copyright files (required by GPL)..."

# Handle ubuntu-keyring (create generic symlink)
echo "Handling keyring naming..."
if [ -f /usr/share/keyrings/ubuntu-archive-keyring.gpg ]; then
    ln -sf /usr/share/keyrings/ubuntu-archive-keyring.gpg /usr/share/keyrings/archive-keyring.gpg 2>/dev/null || true
fi

# Clean any remaining "Ubuntu" strings from user-visible files
echo "Cleaning additional branding strings..."
if [ -f /etc/lsb-release ]; then
    cat > /etc/lsb-release << 'EOF'
DISTRIB_ID=NNFTOS
DISTRIB_RELEASE=1.0
DISTRIB_CODENAME=nnftos
DISTRIB_DESCRIPTION="No Name For This OS 1.0"
EOF
fi

# Remove any Ubuntu-specific default files
rm -f /etc/update-motd.d/*ubuntu* 2>/dev/null || true
rm -f /etc/update-motd.d/10-help-text 2>/dev/null || true

# Create DISCLAIMER file
echo "Creating DISCLAIMER..."
cat > /DISCLAIMER << 'EOF'
================================================================================
                           DISCLAIMER
================================================================================

NO NAME FOR THIS OS (NNFTOS)
Copyright (C) 2025

This software is provided "AS IS", without warranty of any kind, express or
implied, including but not limited to the warranties of merchantability,
fitness for a particular purpose and noninfringement.

--------------------------------------------------------------------------------
TRADEMARK NOTICE
--------------------------------------------------------------------------------

- "Linux" is a registered trademark of Linus Torvalds
- "Ubuntu" is a registered trademark of Canonical Ltd.
- "Debian" is a registered trademark of Software in the Public Interest, Inc.
- "Google" and "Roboto" are trademarks of Google LLC

NNFTOS is NOT affiliated with, endorsed by, or sponsored by:
- Canonical Ltd.
- Ubuntu
- Debian
- Google
- Linus Torvalds
- The Linux Foundation

NNFTOS is an independent Linux distribution that uses packages from various
open source repositories under their respective licenses.

--------------------------------------------------------------------------------
LICENSE INFORMATION
--------------------------------------------------------------------------------

This distribution contains software licensed under:
- GNU General Public License v2 (GPL-2.0)
- GNU General Public License v3 (GPL-3.0)
- GNU Lesser General Public License v2.1 (LGPL-2.1)
- Apache License 2.0
- MIT License
- BSD Licenses

For complete license information, see:
- /COPYING (GPL-2.0)
- /LICENSES/ (All license files)
- /LEGAL.md (Comprehensive legal information)
- /OFFER_OF_SOURCE.txt (Source code offer)

--------------------------------------------------------------------------------
SOURCE CODE
--------------------------------------------------------------------------------

For GPL/LGPL licensed components, source code is available upon request.
Contact: olivierkenzo71@gmail.com

================================================================================
EOF

# Create TRADEMARKS file
echo "Creating TRADEMARKS notice..."
cat > /TRADEMARKS << 'EOF'
================================================================================
                       TRADEMARK NOTICE
================================================================================

This document clarifies the trademark status of various names and logos
referenced in No Name For This OS (NNFTOS).

--------------------------------------------------------------------------------
THIRD-PARTY TRADEMARKS
--------------------------------------------------------------------------------

The following are trademarks of their respective owners:

1. LINUX
   - Owner: Linus Torvalds
   - Status: Registered trademark
   - Usage: Descriptive/nominative use only

2. UBUNTU
   - Owner: Canonical Ltd.
   - Status: Registered trademark
   - Usage: Descriptive only (to indicate package source)
   - We are NOT affiliated with Canonical Ltd.

3. DEBIAN
   - Owner: Software in the Public Interest, Inc.
   - Status: Registered trademark
   - Usage: Descriptive only

4. ROBOTO (Font)
   - Owner: Google LLC
   - Status: Trademark
   - License: Apache 2.0
   - Designer: Christian Robertson

--------------------------------------------------------------------------------
NNFTOS TRADEMARK STATUS
--------------------------------------------------------------------------------

"No Name For This OS" and "NNFTOS" are identifying names for this distribution.
The name intentionally does not claim exclusive trademark rights.

You may:
- Use the name "NNFTOS" to refer to this distribution
- Create derivatives with different names
- Fork this project

--------------------------------------------------------------------------------
ACCEPTABLE USE
--------------------------------------------------------------------------------

When referring to third-party trademarks in NNFTOS:

ACCEPTABLE:
  - "NNFTOS uses packages from Ubuntu repositories"
  - "Based on Ubuntu Base"
  - "Compatible with Debian packages"
  - "Powered by Linux kernel"

NOT ACCEPTABLE:
  - "NNFTOS is Ubuntu"
  - Claiming endorsement by Canonical, Debian, or Google
  - Using Ubuntu/Debian logos as if they were your own
  - Removing copyright/license notices

================================================================================
EOF

# Create motd
echo "Creating MOTD..."
cat > /etc/motd << 'EOF'

  _   _ _______  ___   _      _____ _________  __
 | \ | | ____\ \/ / | | |    / ___|_   _\ \ \/ /
 |  \| |  _|  \  /| | | |___\___ \ | |  \  /
 | |\  | |___ /  \| | | |____|__) || |  /  \
 |_| \_|_____/_/\_\_| |_|    |____/ |_| /_/\_\

  No Name For This OS (NNFTOS)

  A minimal Linux distribution without GUI.
  Based on Ubuntu packages, with independent kernel.

  Type 'nnftos-help' for available commands.
  Type 'neofetch' for system info.

EOF

# Configure bashrc
echo "Configuring bashrc..."
cat >> /etc/bash.bashrc << 'EOF'

# NNFTOS aliases
alias ll='ls -la'
alias la='ls -A'
alias l='ls -CF'
alias update='sudo apt-get update && sudo apt-get upgrade'
alias install='sudo apt-get install'
alias remove='sudo apt-get remove'
alias search='apt-cache search'
alias help='nnftos-help'

# Simple prompt
PS1='\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '

EOF

echo "=== Chroot setup complete ==="
