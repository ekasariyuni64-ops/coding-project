#!/bin/bash
#
# NNFTOS Ubuntu Branding Removal Script
# Removes Ubuntu/Canonical branding to ensure no trademark infringement
#
# License: GPL-2.0
#

set -e

ROOTFS_DIR="${1:-/tmp/rootfs}"

if [ ! -d "$ROOTFS_DIR" ]; then
    echo "Error: Rootfs directory not found: $ROOTFS_DIR"
    exit 1
fi

echo "=== Removing Ubuntu/Canonical Branding ==="
echo "Rootfs: $ROOTFS_DIR"
echo ""

# 1. Remove Ubuntu font family (Canonical IP)
echo "[1/10] Removing Ubuntu font family..."
chroot "$ROOTFS_DIR" apt-get remove -y fonts-ubuntu 2>/dev/null || true
rm -rf "${ROOTFS_DIR}/usr/share/fonts/truetype/ubuntu" 2>/dev/null || true

# 2. Install Roboto font as replacement
echo "[2/10] Installing Roboto font..."
chroot "$ROOTFS_DIR" apt-get install -y fonts-roboto 2>/dev/null || true

# 3. Remove Ubuntu artwork and themes
echo "[3/10] Removing Ubuntu artwork..."
rm -rf "${ROOTFS_DIR}/usr/share/backgrounds/ubuntu" 2>/dev/null || true
rm -rf "${ROOTFS_DIR}/usr/share/themes/Ambiance" 2>/dev/null || true
rm -rf "${ROOTFS_DIR}/usr/share/themes/Radiance" 2>/dev/null || true
rm -rf "${ROOTFS_DIR}/usr/share/icons/ubuntu-mono-dark" 2>/dev/null || true
rm -rf "${ROOTFS_DIR}/usr/share/icons/ubuntu-mono-light" 2>/dev/null || true

# 4. Remove Ubuntu documentation (keep copyright files!)
echo "[4/10] Removing Ubuntu-specific documentation..."
rm -rf "${ROOTFS_DIR}/usr/share/doc/ubuntu-docs" 2>/dev/null || true
rm -f "${ROOTFS_DIR}/usr/share/doc-base/ubuntu*" 2>/dev/null || true

# 5. Clean APT branding
echo "[5/10] Cleaning APT branding..."
rm -f "${ROOTFS_DIR}/etc/apt/apt.conf.d/50ubuntu-cloudimg" 2>/dev/null || true

# 6. Remove Ubuntu One references
echo "[6/10] Removing Ubuntu One references..."
chroot "$ROOTFS_DIR" apt-get remove -y ubuntuone-client ubuntuone-control-panel 2>/dev/null || true
rm -rf "${ROOTFS_DIR}/usr/share/ubuntuone" 2>/dev/null || true

# 7. Clean branding strings from templates
echo "[7/10] Cleaning branding strings..."
find "${ROOTFS_DIR}/usr/share" -type f \( -name "*.txt" -o -name "*.md" -o -name "*.cfg" \) 2>/dev/null | while read -r file; do
    if [ -f "$file" ]; then
        sed -i 's/Powered by Ubuntu//gi' "$file" 2>/dev/null || true
        sed -i 's/Ubuntu One//gi' "$file" 2>/dev/null || true
    fi
done

# 8. Create fontconfig to use Roboto
echo "[8/10] Configuring fonts..."
mkdir -p "${ROOTFS_DIR}/etc/fonts"
cat > "${ROOTFS_DIR}/etc/fonts/local.conf" << 'EOF'
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <match target="pattern">
    <test qual="any" name="family">
      <string>sans-serif</string>
    </test>
    <edit name="family" mode="prepend" binding="strong">
      <string>Roboto</string>
    </edit>
  </match>
  <match target="pattern">
    <test qual="any" name="family">
      <string>monospace</string>
    </test>
    <edit name="family" mode="prepend" binding="strong">
      <string>Roboto Mono</string>
    </edit>
  </match>
</fontconfig>
EOF

# 9. IMPORTANT: Keep copyright files (required by GPL)
echo "[9/10] Preserving copyright files (GPL requirement)..."
# DO NOT DELETE: /usr/share/doc/*/copyright - Required by GPL and Debian Policy
# DO NOT DELETE: /usr/share/doc/*/changelog* - Required by Debian Policy

copyright_count=$(find "${ROOTFS_DIR}/usr/share/doc" -name "copyright" 2>/dev/null | wc -l)
echo "Found $copyright_count copyright files (preserved)"

# 10. Update issue and issue.net
echo "[10/10] Updating system identification..."
cat > "${ROOTFS_DIR}/etc/issue" << 'EOF'
No Name For This OS (NNFTOS) 1.0
\n \l

EOF

cat > "${ROOTFS_DIR}/etc/issue.net" << 'EOF'
No Name For This OS (NNFTOS) 1.0
EOF

echo ""
echo "=== Branding Removal Complete ==="
echo ""
echo "Summary:"
echo "  - Ubuntu fonts removed, Roboto installed"
echo "  - Ubuntu artwork removed"
echo "  - Ubuntu One references removed"
echo "  - Branding strings cleaned"
echo "  - Copyright files preserved (GPL compliance)"
echo ""
