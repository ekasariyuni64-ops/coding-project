# No Name For This OS (NNFTOS)

A minimal Linux distribution derived from Ubuntu Base, designed for lightweight usage without a GUI, featuring its own compiled Linux kernel.

## Overview

**No Name For This OS (NNFTOS)** is a custom Linux distribution that combines the package ecosystem of Ubuntu with a custom-compiled kernel. It is designed to be:

- **Lightweight**: No GUI, minimal packages
- **Independent**: Own kernel, own branding
- **Compatible**: Uses Ubuntu package repositories
- **Legal**: Full compliance with all open source licenses

### Key Features

| Feature | Description |
|---------|-------------|
| Base | Ubuntu Base 26.04 (snapshot 4) |
| Kernel | Linux 7.0-rc3 (custom compiled) |
| Init System | systemd |
| Architecture | arm64 (aarch64) and x86_64 |
| Bootloader | GRUB with EFI support |
| Font | Roboto (Apache 2.0 License) |
| GUI | None (console only) |

## Project Structure

```
nnftos/
├── COPYING                  # GPL-2.0 license text
├── OFFER_OF_SOURCE.txt      # Source code offer (GPL compliance)
├── LEGAL.md                 # Legal information and compliance
├── README.md                # This file
│
├── LICENSES/                # All license texts
│   ├── GPL-2.0.txt
│   ├── GPL-3.0.txt
│   ├── LGPL-2.1.txt
│   ├── Apache-2.0.txt
│   ├── MIT.txt
│   └── Roboto-License.txt
│
├── scripts/                 # Build scripts
│   ├── build-iso.sh         # Main ISO build script
│   ├── build-kernel.sh      # Kernel compilation script
│   ├── chroot-setup.sh      # Chroot configuration
│   └── remove-branding.sh   # Ubuntu branding removal
│
├── configs/                 # Configuration files
│   └── kernel/              # Kernel configs
│       ├── arm64-defconfig
│       └── amd64-defconfig
│
├── rootfs-overlay/          # Files to overlay onto rootfs
│   ├── etc/                 # System configuration
│   │   ├── nnftos-release
│   │   ├── os-release
│   │   └── ...
│   └── usr/local/bin/       # Custom scripts
│       ├── nnftos-install
│       ├── nnftos-help
│       └── nnftos-info
│
├── docs/                    # Documentation
│   ├── BUILD.md
│   ├── CONTRIBUTING.md
│   └── LICENSE-COMPLIANCE.md
│
├── build/                   # Build artifacts (generated)
└── output/                  # Final ISOs (generated)
```

## Quick Start

### Prerequisites

```bash
# Ubuntu/Debian host system required
sudo apt-get update
sudo apt-get install -y \
    debootstrap squashfs-tools xorriso mtools \
    syslinux syslinux-common grub-efi-amd64-bin grub-efi-arm64-bin \
    qemu-user-static binfmt-support build-essential \
    libncurses-dev bison flex libssl-dev libelf-dev bc \
    wget curl git gcc-aarch64-linux-gnu g++-aarch64-linux-gnu
```

### Build ISO

```bash
# Clone or extract the project
cd nnftos

# Make scripts executable
chmod +x scripts/*.sh

# Build for specific architecture
./scripts/build-iso.sh arm64     # ARM64/aarch64
./scripts/build-iso.sh amd64     # x86_64/x64
./scripts/build-iso.sh all       # Both architectures

# ISOs will be in: ./output/
```

### Run in QEMU

```bash
# ARM64
qemu-system-aarch64 \
    -M virt -cpu cortex-a57 -m 1024 \
    -drive file=output/nnftos-arm64.iso,format=raw \
    -nographic

# x86_64
qemu-system-x86_64 \
    -m 1024 \
    -cdrom output/nnftos-amd64.iso \
    -nographic
```

## Default Credentials

| Username | Password | Description |
|----------|----------|-------------|
| root | root | Superuser account |
| nnftos | nnftos | Default user (sudo enabled) |

**Warning: Change these passwords after first boot!**

## License Compliance

NNFTOS is committed to full compliance with all open source licenses:

### GPL Compliance
- Complete source code available upon request
- Written offer for source code in `/OFFER_OF_SOURCE.txt`
- All GPL license texts in `/LICENSES/`
- Copyright files preserved in `/usr/share/doc/*/copyright`

### Removed/Replaced Components

| Original | Replacement | Reason |
|----------|-------------|--------|
| fonts-ubuntu | fonts-roboto | Canonical trademark |
| Ubuntu branding | NNFTOS branding | Trademark compliance |
| Ubuntu artwork | Minimal console | Trademark compliance |

### Contact for Source Code

**Email:** olivierkenzo71@gmail.com

## Differences from Ubuntu

| Aspect | Ubuntu | NNFTOS |
|--------|--------|--------|
| Kernel | Ubuntu-modified | Vanilla Linux 7.0-rc3 |
| GUI | GNOME | None (console) |
| Font | Ubuntu Font Family | Roboto |
| Branding | Ubuntu/Canonical | NNFTOS |
| Target | General desktop/server | Lightweight minimal |

## Contributing

Contributions are welcome! Please read `docs/CONTRIBUTING.md` for guidelines.

## License

- **Kernel**: GPL-2.0-only
- **systemd**: LGPL-2.1-or-later
- **GRUB**: GPL-3.0-or-later
- **Roboto Font**: Apache-2.0
- **Other packages**: Their respective licenses

See `LEGAL.md` for complete licensing information.

---

**Project Maintainer:** olivierkenzo71@gmail.com
**Version:** 1.0
