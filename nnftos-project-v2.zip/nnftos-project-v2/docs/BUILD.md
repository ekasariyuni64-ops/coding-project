# Building NNFTOS

This document provides detailed instructions for building NNFTOS from source.

## System Requirements

### Host System
- **OS**: Ubuntu 22.04/24.04 or Debian 12+ (recommended)
- **Architecture**: x86_64 (for cross-compiling to arm64)
- **CPU**: 4+ cores recommended
- **RAM**: 8GB minimum, 16GB recommended
- **Disk**: 30GB+ free space for full build

## Prerequisites

```bash
# Update package lists
sudo apt-get update

# Install build dependencies
sudo apt-get install -y \
    # Build essentials
    build-essential \
    gcc-aarch64-linux-gnu \
    g++-aarch64-linux-gnu \
    bc \
    bison \
    flex \
    libssl-dev \
    libelf-dev \
    libncurses-dev \
    \
    # System build tools
    debootstrap \
    squashfs-tools \
    xorriso \
    mtools \
    syslinux \
    syslinux-common \
    grub-efi-amd64-bin \
    grub-efi-arm64-bin \
    grub-pc-bin \
    \
    # QEMU for cross-architecture
    qemu-user-static \
    qemu-system-x86 \
    qemu-system-arm \
    binfmt-support \
    \
    # Utilities
    wget \
    curl \
    git \
    cpio \
    gzip \
    xz-utils \
    rsync
```

## Quick Build

```bash
# Clone or extract the project
cd nnftos

# Make scripts executable
chmod +x scripts/*.sh

# Build for specific architecture
./scripts/build-iso.sh arm64     # ARM64/aarch64
./scripts/build-iso.sh amd64     # x86_64/x64
./scripts/build-iso.sh all       # Both architectures

# ISOs will be in: ./output/
ls -la output/
```

## Build Steps Explained

### 1. Download Sources

The build script downloads:
- Ubuntu Base tarball (~100MB per architecture)
- Linux kernel source (~150MB)

### 2. Build Kernel

Kernel compilation takes the longest time:
- Extract kernel source
- Apply NNFTOS configuration
- Compile kernel and modules
- Install to build directory

Estimated time: 30-90 minutes depending on CPU

### 3. Prepare Rootfs

- Extract Ubuntu Base
- Run chroot setup script
- Install additional packages
- Remove Ubuntu branding
- Apply NNFTOS overlay

### 4. Create Initramfs

- Package rootfs into compressed cpio archive

### 5. Create ISO

- Copy kernel and initramfs
- Create squashfs
- Configure GRUB
- Generate bootable ISO

## Configuration

### Kernel Configuration

Kernel configs are located in `configs/kernel/`:
- `arm64-defconfig` - For ARM64
- `amd64-defconfig` - For x86_64

To modify kernel options:
1. Edit the defconfig file
2. Or run `make menuconfig` in the kernel source directory

### Package Selection

Edit `scripts/chroot-setup.sh` to add or remove packages from the `apt-get install` command.

### Rootfs Overlay

Files in `rootfs-overlay/` are copied directly to the rootfs during build.

## Testing

### QEMU (x86_64)

```bash
qemu-system-x86_64 \
    -m 1024 \
    -smp 2 \
    -cdrom output/nnftos-amd64.iso \
    -boot d \
    -nographic
```

### QEMU (ARM64)

```bash
qemu-system-aarch64 \
    -M virt \
    -cpu cortex-a57 \
    -smp 2 \
    -m 1024 \
    -drive file=output/nnftos-arm64.iso,format=raw,if=virtio \
    -nographic
```

### VirtualBox

1. Create new VM
2. Set type: Linux 2.6/3.x/4.x (64-bit)
3. Mount ISO
4. Boot

## Troubleshooting

### Kernel Build Fails

```bash
# Check kernel config
make olddefconfig

# Check for missing dependencies
sudo apt-get install libssl-dev libelf-dev
```

### Chroot Fails

```bash
# Register QEMU binfmt
sudo update-binfmts --enable qemu-aarch64

# Verify
cat /proc/sys/fs/binfmt_misc/qemu-aarch64
```

### ISO Won't Boot

- Check GRUB config
- Verify kernel and initramfs paths
- Check for missing kernel modules

## Build Time Estimates

| Component | ARM64 | x86_64 |
|-----------|-------|--------|
| Download | 10-30 min | 10-30 min |
| Kernel | 30-90 min | 20-60 min |
| Rootfs | 10-20 min | 10-20 min |
| ISO | 5-10 min | 5-10 min |
| **Total** | **60-150 min** | **45-120 min** |

## Support

For issues:
- GitHub Issues: https://github.com/nnftos/nnftos/issues
- Email: olivierkenzo71@gmail.com
