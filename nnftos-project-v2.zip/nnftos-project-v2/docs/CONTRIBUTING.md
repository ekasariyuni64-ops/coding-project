# Contributing to NNFTOS

Thank you for your interest in contributing to NNFTOS! This document provides guidelines for contributions.

## Code of Conduct

- Be respectful and inclusive
- Welcome newcomers
- Accept constructive criticism
- Focus on what's best for the community
- Show empathy towards other community members

## How to Contribute

### Reporting Bugs

1. Check existing issues first
2. Use the bug report template
3. Include:
   - System information (run `nnftos-info`)
   - Steps to reproduce
   - Expected behavior
   - Actual behavior
   - Log output if relevant

### Suggesting Features

1. Open a discussion or issue
2. Describe the feature in detail
3. Explain why it would benefit NNFTOS users
4. Consider implementation complexity

### Submitting Changes

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Test thoroughly
5. Commit with clear messages
6. Push to your fork
7. Submit a pull request

### Pull Request Process

1. Ensure all tests pass
2. Update documentation if needed
3. Follow the coding standards
4. Request review from maintainers
5. Address review comments

## Code Style

### Shell Scripts
- Follow shell script best practices
- Use consistent indentation (4 spaces or tabs)
- Add comments for complex logic
- Keep functions small and focused
- Use `set -e` for error handling

### Kernel Configuration
- Keep kernel minimal
- Document why each option is needed
- Test on real hardware and QEMU

## License Compliance

**IMPORTANT**: All contributions must comply with open source licenses:

1. **Do not add proprietary code**
2. **Do not add trademarked content without permission**
3. **Ensure all code has proper license headers**
4. **Do not remove copyright notices**

### Adding New Packages

When adding packages to the build:

1. Check the package license
2. Ensure license is compatible:
   - GPL-2.0 / GPL-3.0
   - LGPL-2.1 / LGPL-3.0
   - Apache-2.0
   - MIT
   - BSD-2-Clause / BSD-3-Clause
3. Update LEGAL.md if needed
4. Do not add packages with:
   - Proprietary licenses
   - Trademark restrictions
   - Patent encumbrances

### Branding Guidelines

Do not add:
- Ubuntu logos or trademarks
- Canonical branding
- Other distribution's branding

Do add:
- NNFTOS branding (where appropriate)
- License and copyright notices
- Attribution for third-party components

## Development Setup

```bash
# Clone the repository
git clone https://github.com/nnftos/nnftos.git
cd nnftos

# Install dependencies
./scripts/setup-dev.sh

# Build for testing
./scripts/build-iso.sh amd64

# Test in QEMU
qemu-system-x86_64 -m 1024 -cdrom output/nnftos-amd64.iso -nographic
```

## Review Process

1. All PRs require at least one review
2. CI tests must pass
3. License compliance check
4. Documentation update if needed
5. Maintainer approval

## Questions?

Contact: olivierkenzo71@gmail.com

---

Thank you for contributing to free software!
