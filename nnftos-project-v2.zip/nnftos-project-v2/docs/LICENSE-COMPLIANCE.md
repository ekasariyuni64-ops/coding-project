# NNFTOS License Compliance Guide

This document provides detailed information about license compliance for NNFTOS.

## Overview

NNFTOS is committed to full compliance with all open source licenses. We take software freedom seriously and have implemented comprehensive measures to ensure compliance with GPL, LGPL, Apache, MIT, and other open source licenses.

---

## 1. GPL-2.0 Compliance

### Components Licensed Under GPL-2.0

| Component | Source Location |
|-----------|-----------------|
| Linux Kernel 7.0-rc3 | https://kernel.org |
| GNU Core Utilities | https://ftp.gnu.org/gnu/coreutils/ |
| util-linux | https://kernel.org/pub/linux/utils/util-linux/ |
| kmod | https://git.kernel.org/pub/scm/utils/kernel/kmod/kmod.git |

### Compliance Measures

1. **Source Code Offer**
   - File: `/OFFER_OF_SOURCE.txt`
   - Valid for 3 years from distribution date
   - Contact: olivierkenzo71@gmail.com

2. **License Text**
   - File: `/COPYING`
   - File: `/LICENSES/GPL-2.0.txt`

3. **Written Offer (GPL Section 3(b))**
   ```
   Upon written request, we will provide the complete corresponding
   machine-readable source code for all GPL-licensed software.
   ```

4. **No Proprietary Modifications**
   - All modifications to GPL-2.0 components remain under GPL-2.0
   - Source code for modifications available upon request

---

## 2. GPL-3.0 Compliance

### Components Licensed Under GPL-3.0

| Component | Source Location |
|-----------|-----------------|
| GNU GRUB | https://git.savannah.gnu.org/git/grub.git |
| GNU Bash | https://ftp.gnu.org/gnu/bash/ |
| parted | https://git.savannah.gnu.org/git/parted.git |

### Compliance Measures

1. **Source Code Available**
   - Full source available upon request
   - License text: `/LICENSES/GPL-3.0.txt`

2. **Anti-Tivoization (GPL-3.0 Section 6)**
   - Users CAN modify GRUB and reinstall
   - NO secure boot lock-in
   - NO vendor key restrictions
   - Installation media is fully modifiable

3. **Installation Information**
   - GRUB configuration is accessible
   - Users can replace GRUB with alternative bootloaders
   - No cryptographic barriers to modification

---

## 3. LGPL-2.1 Compliance

### Components Licensed Under LGPL-2.1

| Component | Source Location |
|-----------|-----------------|
| systemd | https://github.com/systemd/systemd |
| glibc | https://ftp.gnu.org/gnu/glibc/ |
| dbus | https://gitlab.freedesktop.org/dbus/dbus |

### Compliance Measures

1. **Source Code Available**
   - License text: `/LICENSES/LGPL-2.1.txt`

2. **Linking Freedom**
   - Applications can link against these libraries
   - No restrictions on application licensing
   - Users can replace library versions

3. **Header Files**
   - Required header files included
   - Allows application development

---

## 4. Apache-2.0 Compliance

### Components Licensed Under Apache-2.0

| Component | Source Location |
|-----------|-----------------|
| Roboto Font | https://github.com/googlefonts/roboto |

### Compliance Measures

1. **License Text**
   - File: `/LICENSES/Apache-2.0.txt`
   - File: `/LICENSES/Roboto-License.txt`

2. **Copyright Notice**
   - Copyright (c) Google Inc.
   - Designer: Christian Robertson

3. **Attribution**
   ```
   Font: Roboto by Google
   Designer: Christian Robertson
   License: Apache 2.0
   https://fonts.google.com/specimen/Roboto
   ```

---

## 5. MIT License Compliance

### Components Using MIT License

Various packages and utilities use the MIT license.

### Compliance Measures

- License text: `/LICENSES/MIT.txt`
- Individual copyright notices preserved in source files

---

## 6. Ubuntu/Canonical Compliance

### What Was Removed

| Item | Reason | Replacement |
|------|--------|-------------|
| fonts-ubuntu | Canonical trademark | Roboto (Apache-2.0) |
| Ubuntu artwork | Canonical trademark | Minimal console theme |
| Ubuntu branding | Trademark compliance | NNFTOS branding |
| "Powered by Ubuntu" | Trademark compliance | Removed |

### What Was Retained

| Item | Status |
|------|--------|
| ubuntu-keyring | Functional use (apt), not displayed |
| Package binaries | Used under respective licenses |
| /usr/share/doc/*/copyright | Required by GPL |
| /usr/share/doc/*/changelog* | Required by Debian Policy |

### Trademark Usage

- "Ubuntu" used only in nominative fair use
- No claim of endorsement by Canonical
- Clear statement that NNFTOS is NOT Ubuntu

---

## 7. Copyright Files

### Requirement

Per GPL Section 3 and Debian Policy, copyright files MUST be preserved:

```
/usr/share/doc/*/copyright
/usr/share/doc/*/changelog*
```

### Implementation

- Build scripts explicitly preserve these files
- No cleanup operation removes copyright files
- Verification step in build process

---

## 8. Source Code Request Process

### How to Request Source Code

1. Send email to: olivierkenzo71@gmail.com
2. Include:
   - Name of component(s) needed
   - Preferred delivery method:
     - Email attachment (if small)
     - Download link
     - Physical media (CD/DVD/USB)

### Response Time

- Email/download: Within 10 business days
- Physical media: Within 20 business days

### Cost

- Email/download: Free
- Physical media: Cost of media + shipping

---

## 9. Self-Compliance Checklist

Before distributing NNFTOS, verify:

- [ ] `/COPYING` contains GPL-2.0 full text
- [ ] `/OFFER_OF_SOURCE.txt` is present
- [ ] `/LICENSES/` contains all license texts
- [ ] `/LEGAL.md` is complete
- [ ] `/usr/share/doc/*/copyright` files exist
- [ ] No Ubuntu branding is visible
- [ ] Roboto font is installed
- [ ] Roboto license file is present
- [ ] Source code is available for request

---

## 10. Legal Contact

For licensing questions or source code requests:

**Email:** olivierkenzo71@gmail.com

**Written Requests:**
```
NNFTOS Project
c/o [Your Name]
[Your Address]
[City, Country]
```

---

## 11. Additional Resources

- GPL-2.0: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
- GPL-3.0: https://www.gnu.org/licenses/gpl-3.0.html
- LGPL-2.1: https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
- Apache-2.0: https://www.apache.org/licenses/LICENSE-2.0
- MIT: https://opensource.org/licenses/MIT
- SPDX License List: https://spdx.org/licenses/

---

**Document Version:** 1.0
**Last Updated:** 2025
