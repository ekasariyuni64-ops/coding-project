# No Name For This OS (NNFTOS)

> Ubuntu-based · aarch64/arm64 · systemd · No GUI · Own kernel · QEMU-ready

---

## Spesifikasi

| Item | Detail |
|------|--------|
| **Base** | Ubuntu Base 26.04 Snapshot 4 (arm64) |
| **Kernel** | Linux 7.0-rc3 (cross-compiled) |
| **Arch** | aarch64 / arm64 |
| **Init** | systemd |
| **GUI** | ❌ Tidak ada |
| **Output** | Bootable ISO (installer) |
| **Target** | QEMU virt machine (EFI boot) |

---

## Struktur Project

```
nnftos/
├── build.sh                    ← Main build orchestrator
├── scripts/
│   ├── 01-deps.sh              ← Install host dependencies
│   ├── 02-kernel.sh            ← Download + build kernel
│   ├── 03-rootfs.sh            ← Setup ubuntu-base rootfs
│   ├── chroot-setup.sh         ← Package install (runs in chroot)
│   ├── 04-squash.sh            ← Compress rootfs → squashfs
│   └── 05-iso.sh               ← Build initramfs + final ISO
├── configs/
│   └── grub.cfg                ← GRUB bootloader config
├── overlay/                    ← Files copied into rootfs
│   ├── etc/
│   │   ├── os-release
│   │   └── systemd/system/
│   │       ├── getty@tty1.service.d/autologin.conf
│   │       └── serial-getty@ttyAMA0.service.d/autologin.conf
│   └── usr/local/bin/
│       ├── nnftos-install      ← Disk installer
│       └── nnftos-info         ← System info
├── work/                       ← Build artifacts (generated)
└── output/                     ← Final ISO output
```

---

## Prerequisites (Host Machine)

Host harus **x86_64 Linux** (Ubuntu/Debian recommended) dengan:
- RAM: minimal **4GB** (8GB+ recommended)  
- Disk: minimal **20GB** free space
- Internet connection (untuk download kernel + ubuntu-base)

Estimasi waktu build:
- Download kernel (~100MB): 2-5 menit
- Download ubuntu-base (~35MB): 1-2 menit
- **Build kernel: 15-45 menit** (ini yang paling lama)
- Setup rootfs + packages: 5-20 menit (tergantung koneksi)
- Buat squashfs + ISO: 5-10 menit

---

## Build Instructions

### 1. Full Build (semua langkah)

```bash
sudo bash build.sh
```

### 2. Full Build dengan log

```bash
sudo bash build.sh 2>&1 | tee build.log
```

### 3. Step by step (jika ada yang gagal)

```bash
# Install host dependencies dulu
sudo bash build.sh deps

# Build kernel (paling lama — bisa ditinggal)
sudo bash build.sh kernel

# Setup rootfs
sudo bash build.sh rootfs

# Compress ke squashfs
sudo bash build.sh squash

# Build ISO final
sudo bash build.sh iso
```

### 4. Rebuild ISO tanpa compile kernel lagi

```bash
sudo bash build.sh --skip-kernel rootfs squash iso
```

### 5. Clean build dari awal

```bash
sudo bash build.sh --clean
```

---

## Testing di QEMU

### Install QEMU + EFI firmware

```bash
sudo apt install qemu-system-aarch64 qemu-efi-aarch64
```

### Buat virtual disk (untuk testing installer)

```bash
qemu-img create -f qcow2 output/nnftos-disk.qcow2 10G
```

### Boot dari ISO (live mode)

```bash
qemu-system-aarch64 \
  -machine virt \
  -cpu cortex-a57 \
  -m 2G \
  -smp 2 \
  -bios /usr/share/qemu-efi-aarch64/QEMU_EFI.fd \
  -drive file=output/nnftos-0.1.0-arm64.iso,format=raw,if=virtio,readonly=on,media=cdrom \
  -drive file=output/nnftos-disk.qcow2,format=qcow2,if=virtio \
  -netdev user,id=net0,hostfwd=tcp::2222-:22 \
  -device virtio-net-device,netdev=net0 \
  -nographic \
  -serial stdio
```

> `-nographic -serial stdio` = output di terminal langsung, tidak perlu GUI  
> `hostfwd=tcp::2222-:22` = SSH via `ssh -p 2222 root@localhost`

### Install ke virtual disk

Setelah boot dari ISO, di dalam NNFTOS:

```bash
nnftos-install
```

Ikuti instruksinya, pilih disk `vdb` (virtual disk kedua).

### Boot dari installed disk

```bash
qemu-system-aarch64 \
  -machine virt \
  -cpu cortex-a57 \
  -m 2G \
  -smp 2 \
  -bios /usr/share/qemu-efi-aarch64/QEMU_EFI.fd \
  -drive file=output/nnftos-disk.qcow2,format=qcow2,if=virtio \
  -netdev user,id=net0,hostfwd=tcp::2222-:22 \
  -device virtio-net-device,netdev=net0 \
  -nographic \
  -serial stdio
```

---

## Default Credentials

| User | Password |
|------|----------|
| `root` | `nnftos` |
| `nameless` | `nameless` |

> ⚠️ Ganti password setelah install ke disk!

---

## Features (mirip ubuntu proot-distro)

- ✅ apt package manager (full Ubuntu repos)
- ✅ bash + common utilities (coreutils, util-linux, etc)
- ✅ systemd (init, services, networking)
- ✅ SSH server (openssh-server)
- ✅ Python3 + pip
- ✅ Build tools (gcc, make, cmake)
- ✅ Network stack (iproute2, curl, wget)
- ✅ Text editors (nano, vim-tiny)
- ✅ Terminal multiplexers (tmux, screen)
- ✅ System monitoring (htop, iotop, sysstat)
- ✅ Git
- ✅ Own Linux 7.0-rc3 kernel
- ✅ Kernel modules (virtio, squashfs, ext4, overlay)
- ✅ Disk installer (`nnftos-install`)
- ❌ No GUI / desktop
- ❌ No display server (X11/Wayland)
- ❌ No audio
- ❌ No Bluetooth/WiFi drivers

---

## Troubleshooting

### Kernel build gagal: `pahole not found`
```bash
sudo apt install dwarves
```

### GRUB EFI module tidak ada
```bash
sudo apt install grub-efi-arm64-bin
```

### chroot gagal: `exec format error`
```bash
sudo apt install qemu-user-static binfmt-support
sudo update-binfmts --enable qemu-aarch64
```

### xorriso error: `Cannot find grub-efi-arm64`
```bash
ls /usr/lib/grub/arm64-efi/
# Jika kosong:
sudo apt install grub-efi-arm64-bin
```

### Boot di QEMU stuck di GRUB
- Pastikan `-bios` path benar
- Coba `-cpu max` instead of `-cpu cortex-a57`

---

## Catatan Teknis

**Kenapa kernel custom?**  
NNFTOS punya kernel Linux 7.0-rc3 sendiri dengan config minimal yang dioptimasi untuk QEMU virt machine — tidak ada driver hardware fisik yang tidak perlu (USB, Audio, WiFi, dll).

**Kenapa ubuntu-base?**  
Ubuntu base menyediakan binary arm64 yang sudah proven stable, apt ecosystem, dan kompatibilitas library yang luas — mirip seperti yang dipakai ubuntu proot-distro.

**Boot flow:**  
`QEMU EFI → GRUB (arm64-efi) → vmlinuz → initramfs (squashfs mount + overlayfs) → systemd PID 1 → services → login`

---

*Built with ❤️ — No Name For This OS*
