#!/bin/bash
# ============================================================
#  chroot-setup.sh — Runs INSIDE the arm64 chroot
#  Installs packages, configures systemd, creates users
# ============================================================
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive
export LANG=C.UTF-8
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

echo "[CHROOT] Starting NNFTOS rootfs configuration..."

# ── Fix apt ──────────────────────────────────────────────────
apt-get update -qq 2>&1 | tail -5 || {
  echo "[CHROOT] apt update failed — check network / sources.list"
  cat /etc/apt/sources.list
  exit 1
}

# ── Install packages ─────────────────────────────────────────
PKGS_CORE=(
  # Init / base
  systemd systemd-sysv dbus
  # Core utils
  bash coreutils util-linux procps
  # Package management
  apt dpkg apt-utils
  # Network tools
  iproute2 iproute2-doc iputils-ping
  net-tools dnsutils
  curl wget
  # SSH
  openssh-server openssh-client
  # Editors
  nano vim-tiny
  # File tools
  less file findutils diffutils patch
  # Archives
  tar gzip bzip2 xz-utils zip unzip
  # Process tools
  htop psmisc lsof
  # Terminal multiplexers
  tmux screen
  # Misc
  sudo ca-certificates gnupg
  locales tzdata
  man-db manpages
  # Login
  login passwd shadow
  # Hardware info
  lshw dmidecode
  # Logging
  rsyslog
  # Boot / disk tools
  parted fdisk gdisk dosfstools e2fsprogs
  grub-efi-arm64
)

PKGS_DEV=(
  # Development
  build-essential gcc g++ make cmake
  python3 python3-pip python3-venv
  git
  # Scripting
  perl lua5.4
  # Libraries
  libssl-dev libffi-dev
  # Debugging
  strace gdb
)

PKGS_EXTRA=(
  # Network extras
  nmap netcat-openbsd socat
  # DNS/TLS
  bind9-host
  # Monitoring
  sysstat iotop
  # Text processing
  jq awk sed grep
  moreutils
  # Shell extras
  bash-completion
  # Disk monitoring
  smartmontools
)

echo "[CHROOT] Installing core packages..."
apt-get install -y --no-install-recommends "${PKGS_CORE[@]}"

echo "[CHROOT] Installing development tools..."
apt-get install -y --no-install-recommends "${PKGS_DEV[@]}"

echo "[CHROOT] Installing extra utilities..."
apt-get install -y --no-install-recommends "${PKGS_EXTRA[@]}" || \
  echo "[CHROOT] Some extra packages unavailable — skipping"

# ── Locale ───────────────────────────────────────────────────
echo "en_US.UTF-8 UTF-8" > /etc/locale.gen
locale-gen
update-locale LANG=en_US.UTF-8

# ── Timezone ─────────────────────────────────────────────────
ln -sf /usr/share/zoneinfo/UTC /etc/localtime
echo "UTC" > /etc/timezone

# ── Hostname ─────────────────────────────────────────────────
echo "nnftos" > /etc/hostname
cat > /etc/hosts <<'EOF'
127.0.0.1   localhost
127.0.1.1   nnftos
::1         localhost ip6-localhost ip6-loopback
ff02::1     ip6-allnodes
ff02::2     ip6-allrouters
EOF

# ── Root password ─────────────────────────────────────────────
echo "[CHROOT] Setting root password to 'nnftos' (change on first boot!)"
echo "root:nnftos" | chpasswd

# ── Default user ─────────────────────────────────────────────
echo "[CHROOT] Creating default user 'nameless'..."
useradd -m -s /bin/bash -G sudo,adm,audio,video,plugdev nameless
echo "nameless:nameless" | chpasswd
echo "nameless ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/nameless
chmod 440 /etc/sudoers.d/nameless

# ── systemd services ─────────────────────────────────────────
echo "[CHROOT] Configuring systemd..."

# Enable essential services
systemctl enable systemd-networkd.service 2>/dev/null || true
systemctl enable systemd-resolved.service 2>/dev/null || true
systemctl enable ssh.service 2>/dev/null || true
systemctl enable rsyslog.service 2>/dev/null || true
systemctl enable getty@tty1.service 2>/dev/null || true
systemctl enable serial-getty@ttyAMA0.service 2>/dev/null || true

# Disable unnecessary services
systemctl disable apt-daily.service 2>/dev/null || true
systemctl disable apt-daily-upgrade.service 2>/dev/null || true
systemctl disable man-db.service 2>/dev/null || true

# ── systemd-networkd: configure eth0 ────────────────────────
mkdir -p /etc/systemd/network
cat > /etc/systemd/network/20-wired.network <<'EOF'
[Match]
Name=en* eth*

[Network]
DHCP=yes
DNS=8.8.8.8 1.1.1.1
IPv6AcceptRA=yes
LinkLocalAddressing=ipv6

[DHCPv4]
RouteMetric=100
UseDNS=yes
UseDomains=yes
EOF

# ── SSH config ────────────────────────────────────────────────
mkdir -p /etc/ssh
cat >> /etc/ssh/sshd_config <<'EOF'
# NNFTOS SSH config
PermitRootLogin yes
PasswordAuthentication yes
UsePAM yes
EOF

# ── Bash profile ─────────────────────────────────────────────
cat > /etc/profile.d/nnftos.sh <<'EOF'
# No Name For This OS — profile
export PS1='\[\033[1;32m\]\u\[\033[0m\]@\[\033[1;34m\]\h\[\033[0m\]:\[\033[1;33m\]\w\[\033[0m\]\$ '
export EDITOR=nano
alias ls='ls --color=auto'
alias ll='ls -alF --color=auto'
alias la='ls -A --color=auto'
alias grep='grep --color=auto'
alias df='df -h'
alias free='free -h'
alias ..='cd ..'
alias ...='cd ../..'

# NNFTOS info
nnftos-info() {
  echo ""
  echo "  ╔═══════════════════════════════════╗"
  echo "  ║   No Name For This OS  v0.1.0     ║"
  echo "  ║   Kernel: $(uname -r)"
  echo "  ║   Arch:   $(uname -m)"
  echo "  ╚═══════════════════════════════════╝"
  echo ""
}
EOF

# ── MOTD ──────────────────────────────────────────────────────
cat > /etc/motd <<'EOF'

  ╔══════════════════════════════════════════════════════╗
  ║          N o   N a m e   F o r   T h i s   O S      ║
  ║                    version 0.1.0                     ║
  ║          Ubuntu-based · aarch64 · systemd            ║
  ╚══════════════════════════════════════════════════════╝

  Credentials:
    root user  →  root:nnftos
    default    →  nameless:nameless

  Run 'nnftos-install' to install to disk.
  Run 'nnftos-info' for system info.

EOF

# ── issue (pre-login banner) ──────────────────────────────────
cat > /etc/issue <<'EOF'
No Name For This OS 0.1.0 \n \l

EOF

# ── fstab (live mode / will be regenerated on install) ───────
cat > /etc/fstab <<'EOF'
# /etc/fstab — generated by NNFTOS build system
# Actual entries will be written by nnftos-install
proc            /proc    proc    defaults     0 0
sysfs           /sys     sysfs   defaults     0 0
devpts          /dev/pts devpts  gid=5,mode=620 0 0
tmpfs           /tmp     tmpfs   defaults     0 0
EOF

# ── Clean up ─────────────────────────────────────────────────
echo "[CHROOT] Cleaning up..."
apt-get autoremove -y --purge 2>/dev/null || true
apt-get clean
rm -rf /var/lib/apt/lists/*
rm -rf /var/cache/apt/*
rm -rf /tmp/* /var/tmp/*
find /var/log -type f -delete 2>/dev/null || true

echo "[CHROOT] Rootfs configuration complete!"
