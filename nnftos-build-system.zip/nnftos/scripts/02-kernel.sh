#!/usr/bin/env bash
# ============================================================
#  02-kernel.sh — Download & cross-compile Linux kernel
#  Target: aarch64 / arm64 — QEMU virt machine
# ============================================================
set -euo pipefail

BUILD_DIR="$(cd "$(dirname "$0")/.." && pwd)"
source "${BUILD_DIR}/build.sh" 2>/dev/null || true

WORK_DIR="${BUILD_DIR}/work"
KERNEL_SRC="${WORK_DIR}/kernel-src"
KERNEL_OUT="${WORK_DIR}/kernel-out"
KERNEL_URL="${KERNEL_URL:-https://git.kernel.org/torvalds/t/linux-7.0-rc3.tar.gz}"
KERNEL_TARBALL="${WORK_DIR}/linux-7.0-rc3.tar.gz"
CROSS_COMPILE="${CROSS_COMPILE:-aarch64-linux-gnu-}"
ARCH="arm64"
JOBS="$(nproc)"

log() { echo -e "\033[0;32m[KERNEL]\033[0m $*"; }
err() { echo -e "\033[0;31m[KERNEL ERROR]\033[0m $*" >&2; exit 1; }

mkdir -p "${WORK_DIR}" "${KERNEL_OUT}"

# ── Download ─────────────────────────────────────────────────
if [[ ! -f "${KERNEL_TARBALL}" ]]; then
  log "Downloading Linux kernel from ${KERNEL_URL} ..."
  wget -c -O "${KERNEL_TARBALL}" "${KERNEL_URL}" || \
    err "Failed to download kernel. Check URL or your connection."
fi

# ── Extract ───────────────────────────────────────────────────
if [[ ! -d "${KERNEL_SRC}" ]]; then
  log "Extracting kernel source..."
  mkdir -p "${KERNEL_SRC}"
  tar -xzf "${KERNEL_TARBALL}" -C "${KERNEL_SRC}" --strip-components=1
fi

cd "${KERNEL_SRC}"

# ── Configure ─────────────────────────────────────────────────
log "Generating defconfig for arm64..."
make ARCH="${ARCH}" CROSS_COMPILE="${CROSS_COMPILE}" O="${KERNEL_OUT}" defconfig

log "Applying custom config options for NNFTOS..."

KCONF="${KERNEL_SRC}/scripts/config --file ${KERNEL_OUT}/.config"

# Enable QEMU virt machine
$KCONF -e CONFIG_ARCH_VIRT

# VirtIO drivers (essential for QEMU)
$KCONF -e CONFIG_VIRTIO
$KCONF -e CONFIG_VIRTIO_PCI
$KCONF -e CONFIG_VIRTIO_BLK
$KCONF -e CONFIG_VIRTIO_NET
$KCONF -e CONFIG_VIRTIO_BALLOON
$KCONF -e CONFIG_VIRTIO_MMIO
$KCONF -e CONFIG_VIRTIO_INPUT
$KCONF -e CONFIG_VIRTIO_CONSOLE

# Filesystems
$KCONF -e CONFIG_EXT4_FS
$KCONF -e CONFIG_EXT4_USE_FOR_EXT2
$KCONF -e CONFIG_VFAT_FS
$KCONF -e CONFIG_FAT_FS
$KCONF -e CONFIG_SQUASHFS
$KCONF -e CONFIG_SQUASHFS_XZ
$KCONF -e CONFIG_SQUASHFS_LZ4
$KCONF -e CONFIG_OVERLAY_FS
$KCONF -e CONFIG_TMPFS
$KCONF -e CONFIG_TMPFS_POSIX_ACL
$KCONF -e CONFIG_PROC_FS
$KCONF -e CONFIG_SYSFS
$KCONF -e CONFIG_DEVTMPFS
$KCONF -e CONFIG_DEVTMPFS_MOUNT
$KCONF -e CONFIG_NLS_CODEPAGE_437
$KCONF -e CONFIG_NLS_ISO8859_1
$KCONF -e CONFIG_NLS_UTF8

# EFI support (for UEFI boot)
$KCONF -e CONFIG_EFI
$KCONF -e CONFIG_EFIVAR_FS
$KCONF -e CONFIG_EFI_STUB

# cgroups + namespaces (required by systemd)
$KCONF -e CONFIG_CGROUPS
$KCONF -e CONFIG_CGROUP_SCHED
$KCONF -e CONFIG_CGROUP_BPF
$KCONF -e CONFIG_BLK_CGROUP
$KCONF -e CONFIG_MEMCG
$KCONF -e CONFIG_CGROUP_DEVICE
$KCONF -e CONFIG_CGROUP_CPUACCT
$KCONF -e CONFIG_CGROUP_PERF
$KCONF -e CONFIG_CGROUP_FREEZER
$KCONF -e CONFIG_CPUSETS
$KCONF -e CONFIG_NAMESPACES
$KCONF -e CONFIG_NET_NS
$KCONF -e CONFIG_PID_NS
$KCONF -e CONFIG_IPC_NS
$KCONF -e CONFIG_UTS_NS
$KCONF -e CONFIG_USER_NS
$KCONF -e CONFIG_TIME_NS

# Networking
$KCONF -e CONFIG_NET
$KCONF -e CONFIG_INET
$KCONF -e CONFIG_IPV6
$KCONF -e CONFIG_PACKET
$KCONF -e CONFIG_UNIX
$KCONF -e CONFIG_NETFILTER
$KCONF -e CONFIG_IP_NF_IPTABLES
$KCONF -e CONFIG_IP_NF_FILTER
$KCONF -e CONFIG_IP_NF_NAT
$KCONF -e CONFIG_NF_CONNTRACK
$KCONF -e CONFIG_NET_SCHED

# Security
$KCONF -e CONFIG_SECURITY
$KCONF -e CONFIG_SECURITY_APPARMOR
$KCONF -e CONFIG_SECURITYFS
$KCONF -e CONFIG_SECCOMP
$KCONF -e CONFIG_SECCOMP_FILTER

# Crypto (needed by many things)
$KCONF -e CONFIG_CRYPTO_SHA256
$KCONF -e CONFIG_CRYPTO_AES
$KCONF -e CONFIG_CRYPTO_GCM

# Misc / inotify / fanotify (systemd needs these)
$KCONF -e CONFIG_INOTIFY_USER
$KCONF -e CONFIG_FANOTIFY
$KCONF -e CONFIG_POSIX_MQUEUE
$KCONF -e CONFIG_EPOLL
$KCONF -e CONFIG_SIGNALFD
$KCONF -e CONFIG_TIMERFD
$KCONF -e CONFIG_EVENTFD
$KCONF -e CONFIG_SHMEM

# Disable heavy things to keep it lightweight
$KCONF -d CONFIG_DRM              # No display
$KCONF -d CONFIG_SOUND            # No audio
$KCONF -d CONFIG_USB              # No USB (QEMU virt doesn't need it)
$KCONF -d CONFIG_WIRELESS         # No WiFi
$KCONF -d CONFIG_BLUETOOTH        # No BT
$KCONF -d CONFIG_NFC              # No NFC
$KCONF -d CONFIG_MEDIA_SUPPORT    # No media
$KCONF -d CONFIG_EDAC             # No hardware error correction
$KCONF -d CONFIG_POWER_SUPPLY     # Not needed in VM
$KCONF -d CONFIG_BATTERY          # Not needed in VM

# Console
$KCONF -e CONFIG_SERIAL_AMBA_PL011
$KCONF -e CONFIG_SERIAL_AMBA_PL011_CONSOLE
$KCONF -e CONFIG_VIRTIO_CONSOLE

# Resolve config dependencies
log "Running olddefconfig to resolve dependencies..."
make ARCH="${ARCH}" CROSS_COMPILE="${CROSS_COMPILE}" O="${KERNEL_OUT}" olddefconfig

# ── Build ────────────────────────────────────────────────────
log "Building kernel with ${JOBS} jobs... (this takes ~15-45 mins)"
log "You can watch progress with: tail -f /tmp/kernel-build.log"

make ARCH="${ARCH}" CROSS_COMPILE="${CROSS_COMPILE}" O="${KERNEL_OUT}" \
  -j"${JOBS}" 2>&1 | tee /tmp/kernel-build.log

# ── Copy outputs ─────────────────────────────────────────────
KERNEL_ARTIFACTS="${WORK_DIR}/kernel-artifacts"
mkdir -p "${KERNEL_ARTIFACTS}"

cp "${KERNEL_OUT}/arch/arm64/boot/Image" "${KERNEL_ARTIFACTS}/vmlinuz"
log "Kernel Image → ${KERNEL_ARTIFACTS}/vmlinuz"

# Copy modules
log "Installing kernel modules..."
make ARCH="${ARCH}" CROSS_COMPILE="${CROSS_COMPILE}" O="${KERNEL_OUT}" \
  INSTALL_MOD_PATH="${KERNEL_ARTIFACTS}" modules_install

# Save kernel version string
KVER=$(cat "${KERNEL_OUT}/include/config/kernel.release")
echo "${KVER}" > "${KERNEL_ARTIFACTS}/kernel.version"
log "Kernel version: ${KVER}"
log "Kernel build complete!"
