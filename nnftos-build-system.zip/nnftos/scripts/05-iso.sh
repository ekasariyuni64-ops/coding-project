#!/usr/bin/env bash
# ============================================================
#  05-iso.sh — Build initramfs + assemble bootable ISO
#  Architecture: aarch64 — EFI boot via GRUB
# ============================================================
set -euo pipefail

BUILD_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WORK_DIR="${BUILD_DIR}/work"
ROOTFS="${WORK_DIR}/rootfs"
KERNEL_ARTIFACTS="${WORK_DIR}/kernel-artifacts"
ISO_STAGE="${WORK_DIR}/iso-stage"
OUT_DIR="${BUILD_DIR}/output"
OS_VERSION="${OS_VERSION:-0.1.0}"

log()  { echo -e "\033[0;32m[ISO]\033[0m $*"; }
err()  { echo -e "\033[0;31m[ISO ERROR]\033[0m $*" >&2; exit 1; }
step() { echo -e "\n\033[1;36m  ── $* ──\033[0m\n"; }

# ── Verify prerequisites ─────────────────────────────────────
[[ -f "${KERNEL_ARTIFACTS}/vmlinuz" ]] || \
  err "Kernel not found: ${KERNEL_ARTIFACTS}/vmlinuz — run 02-kernel.sh first"
[[ -f "${WORK_DIR}/filesystem.squashfs" ]] || \
  err "Squashfs not found — run 04-squash.sh first"

mkdir -p "${ISO_STAGE}/boot/grub"
mkdir -p "${ISO_STAGE}/live"
mkdir -p "${ISO_STAGE}/EFI/BOOT"
mkdir -p "${OUT_DIR}"

# ════════════════════════════════════════════════════════════
#  INITRAMFS
# ════════════════════════════════════════════════════════════
step "Building initramfs"

INITRAMFS_DIR="${WORK_DIR}/initramfs-build"
rm -rf "${INITRAMFS_DIR}"
mkdir -p "${INITRAMFS_DIR}"/{bin,sbin,lib,lib64,proc,sys,dev,tmp,mnt/{live,overlay/{lower,upper,work},root},run/systemd,newroot}

# ── Copy busybox (from rootfs) ────────────────────────────────
# We use busybox from the rootfs as our initramfs userspace
BUSYBOX=""
for candidate in \
  "${ROOTFS}/bin/busybox" \
  "${ROOTFS}/usr/bin/busybox" \
  /usr/aarch64-linux-gnu/bin/busybox; do
  if [[ -f "$candidate" ]]; then
    BUSYBOX="$candidate"
    break
  fi
done

if [[ -z "$BUSYBOX" ]]; then
  log "busybox not in rootfs — building minimal shell from rootfs binaries..."
  # Copy minimal binaries from rootfs
  for bin in sh bash mount umount switch_root mknod mkdir ln sleep; do
    for path in "${ROOTFS}/bin/$bin" "${ROOTFS}/usr/bin/$bin" \
                "${ROOTFS}/sbin/$bin" "${ROOTFS}/usr/sbin/$bin"; do
      if [[ -f "$path" ]]; then
        cp "$path" "${INITRAMFS_DIR}/bin/"
        # Copy shared libs
        ldd "$path" 2>/dev/null | grep "=> /" | awk '{print $3}' | while read -r lib; do
          libdir=$(dirname "$lib")
          mkdir -p "${INITRAMFS_DIR}${libdir}"
          cp -L "$lib" "${INITRAMFS_DIR}${libdir}/" 2>/dev/null || true
        done
        break
      fi
    done
  done
else
  cp "${BUSYBOX}" "${INITRAMFS_DIR}/bin/busybox"
  # Create busybox applets
  for applet in sh ash mount umount switch_root mknod mkdir ln sleep \
                ls cp cat echo find grep awk sed modprobe; do
    ln -sf busybox "${INITRAMFS_DIR}/bin/$applet" 2>/dev/null || true
  done
fi

# ── Write the initramfs init script ──────────────────────────
cat > "${INITRAMFS_DIR}/init" <<'INIT_SCRIPT'
#!/bin/sh
# ============================================================
#  NNFTOS initramfs init
#  Mounts squashfs live filesystem with overlayfs
# ============================================================
export PATH=/bin:/sbin:/usr/bin:/usr/sbin

# Basic mounts
mount -t proc     none /proc
mount -t sysfs    none /sys
mount -t devtmpfs none /dev  2>/dev/null || \
  mount -t tmpfs    none /dev
mkdir -p /dev/pts
mount -t devpts   none /dev/pts
mount -t tmpfs    none /tmp
mount -t tmpfs    none /run

# Kernel messages: only warnings
echo 4 > /proc/sys/kernel/printk 2>/dev/null || true

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║   No Name For This OS — Booting...   ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# ── Load kernel modules for virtio + filesystems ─────────────
for mod in virtio virtio_pci virtio_blk virtio_net \
           squashfs overlay ext4; do
  modprobe "$mod" 2>/dev/null || true
done

# ── Find and mount live media ────────────────────────────────
SQUASH=""
TRIES=0
MAX_TRIES=20

echo "  Searching for live filesystem..."

while [ -z "$SQUASH" ] && [ "$TRIES" -lt "$MAX_TRIES" ]; do
  TRIES=$((TRIES + 1))
  sleep 0.5

  for dev in /dev/vda /dev/sda /dev/mmcblk0 /dev/vdb /dev/sdb; do
    [ -b "$dev" ] || continue
    # Try mounting as ISO9660 or vfat (ISO has EFI partition)
    for fstype in iso9660 vfat; do
      mount -t "$fstype" -o ro "$dev" /mnt/live 2>/dev/null && {
        if [ -f "/mnt/live/live/filesystem.squashfs" ]; then
          SQUASH="/mnt/live/live/filesystem.squashfs"
          LIVE_DEV="$dev"
          break 2
        fi
        umount /mnt/live 2>/dev/null || true
      }
    done
    # Also try raw partition
    for part in "${dev}"1 "${dev}"2 "${dev}p1" "${dev}p2"; do
      [ -b "$part" ] || continue
      mount -t iso9660 -o ro "$part" /mnt/live 2>/dev/null && {
        if [ -f "/mnt/live/live/filesystem.squashfs" ]; then
          SQUASH="/mnt/live/live/filesystem.squashfs"
          LIVE_DEV="$part"
          break 3
        fi
        umount /mnt/live 2>/dev/null || true
      }
    done
  done
done

if [ -z "$SQUASH" ]; then
  echo "  ERROR: Could not find live filesystem!"
  echo "  Dropping into emergency shell..."
  exec /bin/sh
fi

echo "  Live media: ${LIVE_DEV}"

# ── Mount squashfs ────────────────────────────────────────────
echo "  Mounting squashfs..."
mount -t squashfs -o ro,loop "$SQUASH" /mnt/overlay/lower || {
  echo "  ERROR: Failed to mount squashfs!"
  exec /bin/sh
}

# ── Overlay ───────────────────────────────────────────────────
echo "  Setting up overlayfs..."
mount -t tmpfs tmpfs /mnt/overlay/upper
mkdir -p /mnt/overlay/upper/upper /mnt/overlay/upper/work

mount -t overlay overlay \
  -o lowerdir=/mnt/overlay/lower,upperdir=/mnt/overlay/upper/upper,workdir=/mnt/overlay/upper/work \
  /newroot || {
  echo "  Overlay failed — mounting squashfs directly (read-only)"
  mount --bind /mnt/overlay/lower /newroot
}

# ── Prepare newroot ───────────────────────────────────────────
echo "  Preparing root filesystem..."
mkdir -p /newroot/{proc,sys,dev,run,tmp}

# Move mount points into newroot
mount --move /mnt/live /newroot/mnt/live 2>/dev/null || \
  mount --bind /mnt/live /newroot/mnt/live 2>/dev/null || true

# ── Switch root ───────────────────────────────────────────────
echo "  Switching to root filesystem..."
echo ""

# Hand off to systemd
exec switch_root /newroot /sbin/init
INIT_SCRIPT

chmod +x "${INITRAMFS_DIR}/init"

# ── Copy kernel modules into initramfs ────────────────────────
if [[ -d "${KERNEL_ARTIFACTS}/lib/modules" ]]; then
  log "Embedding kernel modules in initramfs..."
  KVER=$(cat "${KERNEL_ARTIFACTS}/kernel.version" 2>/dev/null || ls "${KERNEL_ARTIFACTS}/lib/modules/")
  mkdir -p "${INITRAMFS_DIR}/lib/modules/${KVER}"
  cp -r "${KERNEL_ARTIFACTS}/lib/modules/${KVER}"/* \
    "${INITRAMFS_DIR}/lib/modules/${KVER}/" 2>/dev/null || true
fi

# ── Pack initramfs ────────────────────────────────────────────
log "Packing initramfs..."
INITRD="${WORK_DIR}/initrd.img"
(cd "${INITRAMFS_DIR}" && find . | cpio -H newc -o 2>/dev/null | gzip -9 > "${INITRD}")
INITRD_SIZE=$(du -sh "${INITRD}" | cut -f1)
log "initrd.img created: ${INITRD_SIZE}"

# ════════════════════════════════════════════════════════════
#  ISO STAGE
# ════════════════════════════════════════════════════════════
step "Assembling ISO layout"

# ── Copy kernel + initrd ──────────────────────────────────────
cp "${KERNEL_ARTIFACTS}/vmlinuz" "${ISO_STAGE}/boot/vmlinuz"
cp "${INITRD}" "${ISO_STAGE}/boot/initrd.img"

# ── Copy squashfs ─────────────────────────────────────────────
cp "${WORK_DIR}/filesystem.squashfs" "${ISO_STAGE}/live/filesystem.squashfs"

# ── GRUB config ───────────────────────────────────────────────
cp "${BUILD_DIR}/configs/grub.cfg" "${ISO_STAGE}/boot/grub/grub.cfg"

# ── Build GRUB EFI image ──────────────────────────────────────
step "Building GRUB EFI binary (BOOTAA64.EFI)"

EFI_DIR="${WORK_DIR}/efi-build"
mkdir -p "${EFI_DIR}"

# grub modules needed for arm64 EFI boot from ISO9660
GRUB_MODULES="all_video boot btrfs cat chain configfile echo \
  efifwsetup efinet ext2 fat font gettext gfxterm gfxterm_background \
  gfxterm_menu gzip halt help hfsplus iso9660 jpeg keystatus \
  loadenv loopback linux memdisk minicmd normal ntfs part_apple \
  part_gpt part_msdos password_pbkdf2 png probe reboot regexp search \
  search_fs_file search_fs_uuid search_label sleep squash4 \
  test true video xfs zfs zfsinfo"

grub-mkimage \
  --format=arm64-efi \
  --output="${ISO_STAGE}/EFI/BOOT/BOOTAA64.EFI" \
  --prefix=/boot/grub \
  --config="${BUILD_DIR}/configs/grub.cfg" \
  --directory=/usr/lib/grub/arm64-efi \
  $GRUB_MODULES

log "GRUB EFI binary built: EFI/BOOT/BOOTAA64.EFI"

# ── Build EFI system partition image ─────────────────────────
step "Creating EFI system partition image"

EFI_IMG="${WORK_DIR}/efi.img"
EFI_IMG_SIZE=8M  # 8MB is enough for grub + config

dd if=/dev/zero of="${EFI_IMG}" bs=1M count=8 2>/dev/null
mkfs.vfat -F12 -n "NNFTOS_EFI" "${EFI_IMG}"

# Populate EFI image with boot files
mmd -i "${EFI_IMG}" ::EFI ::EFI/BOOT
mcopy -i "${EFI_IMG}" "${ISO_STAGE}/EFI/BOOT/BOOTAA64.EFI" ::EFI/BOOT/BOOTAA64.EFI

# Also copy grub.cfg into EFI image for UEFI firmware
mmd -i "${EFI_IMG}" ::boot ::boot/grub
mcopy -i "${EFI_IMG}" "${BUILD_DIR}/configs/grub.cfg" ::boot/grub/grub.cfg

# ── Build final ISO ───────────────────────────────────────────
step "Building final ISO with xorriso"

ISO_OUT="${OUT_DIR}/nnftos-${OS_VERSION}-arm64.iso"

xorriso -as mkisofs \
  -r \
  -V "NNFTOS_${OS_VERSION}" \
  --modification-date="$(date -u +%Y%m%d%H%M%S)00" \
  -J -joliet-long \
  -l \
  --iso-level 3 \
  --no-pad \
  -isohybrid-gpt-basdat "${EFI_IMG}" \
  -e --interval:appended_partition_1:all:: \
  -no-emul-boot \
  -append_partition 2 0xef "${EFI_IMG}" \
  -appended_part_as_gpt \
  -output "${ISO_OUT}" \
  "${ISO_STAGE}"

ISO_SIZE=$(du -sh "${ISO_OUT}" | cut -f1)
ISO_SHA256=$(sha256sum "${ISO_OUT}" | cut -d' ' -f1)

log "╔═══════════════════════════════════════════════╗"
log "║  ISO build complete!                          ║"
log "║  File:   ${ISO_OUT}"
log "║  Size:   ${ISO_SIZE}"
log "║  SHA256: ${ISO_SHA256:0:32}..."
log "╚═══════════════════════════════════════════════╝"

# Write checksum file
echo "${ISO_SHA256}  nnftos-${OS_VERSION}-arm64.iso" > "${OUT_DIR}/nnftos-${OS_VERSION}-arm64.iso.sha256"
log "Checksum saved to: nnftos-${OS_VERSION}-arm64.iso.sha256"
