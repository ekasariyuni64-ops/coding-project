#!/usr/bin/env bash
# ============================================================
#  04-squash.sh — Compress rootfs into squashfs
# ============================================================
set -euo pipefail

BUILD_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WORK_DIR="${BUILD_DIR}/work"
ROOTFS="${WORK_DIR}/rootfs"
SQUASH_OUT="${WORK_DIR}/filesystem.squashfs"

log() { echo -e "\033[0;32m[SQUASH]\033[0m $*"; }
err() { echo -e "\033[0;31m[SQUASH ERROR]\033[0m $*" >&2; exit 1; }

[[ -d "${ROOTFS}" ]] || err "Rootfs not found at ${ROOTFS}. Run 03-rootfs.sh first."

log "Creating squashfs from rootfs..."
log "Source: ${ROOTFS}"
log "Output: ${SQUASH_OUT}"

# Remove old squashfs
rm -f "${SQUASH_OUT}"

# Create squashfs with xz compression (best compression for read-only live FS)
mksquashfs "${ROOTFS}" "${SQUASH_OUT}" \
  -comp xz \
  -Xbcj arm \
  -b 1M \
  -no-progress \
  -noappend \
  -wildcards \
  -e \
    "proc/*" \
    "sys/*" \
    "dev/*" \
    "run/*" \
    "tmp/*" \
    "var/tmp/*" \
    "var/cache/apt/archives/*.deb" \
    "var/lib/apt/lists/*" \
    "root/.bash_history" \
    "home/*/.bash_history"

SQUASH_SIZE=$(du -sh "${SQUASH_OUT}" | cut -f1)
log "Squashfs created: ${SQUASH_OUT} (${SQUASH_SIZE})"
