#!/usr/bin/env bash
# ============================================================
#  01-deps.sh — Install host build dependencies
# ============================================================
set -euo pipefail
source "$(dirname "$0")/../build.sh" 2>/dev/null || true

log() { echo -e "\033[0;32m[DEPS]\033[0m $*"; }
log "Installing build dependencies on host..."

apt-get update -qq

PKGS=(
  # Cross-compiler toolchain for arm64
  gcc-aarch64-linux-gnu
  g++-aarch64-linux-gnu
  binutils-aarch64-linux-gnu
  # Kernel build requirements
  bc bison flex libssl-dev libelf-dev
  libncurses-dev dwarves pahole
  make gcc pkg-config
  # Rootfs tools
  debootstrap qemu-user-static binfmt-support
  # chroot tools
  systemd-container
  # Squashfs + ISO tools
  squashfs-tools xorriso grub-efi-arm64-bin
  # QEMU for testing
  qemu-system-aarch64 qemu-efi-aarch64
  # Misc
  wget curl git tar gzip xz-utils
  dosfstools mtools
)

apt-get install -y --no-install-recommends "${PKGS[@]}"

# Enable binfmt for aarch64 so we can run arm64 binaries in chroot
log "Setting up binfmt_misc for aarch64..."
update-binfmts --enable qemu-aarch64 2>/dev/null || true

log "Dependencies installed successfully."
