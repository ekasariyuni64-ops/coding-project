#!/usr/bin/env bash
# ============================================================
#  03-rootfs.sh — Setup rootfs from ubuntu-base arm64
# ============================================================
set -euo pipefail

BUILD_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WORK_DIR="${BUILD_DIR}/work"
ROOTFS="${WORK_DIR}/rootfs"
UBUNTU_BASE_URL="${UBUNTU_BASE_URL:-https://cdimage.ubuntu.com/ubuntu-base/releases/26.04/snapshot-4/ubuntu-base-26.04-snapshot4-base-arm64.tar.gz}"
TARBALL="${WORK_DIR}/ubuntu-base-arm64.tar.gz"
OVERLAY_DIR="${BUILD_DIR}/overlay"
SCRIPTS_DIR="${BUILD_DIR}/scripts"
KERNEL_ARTIFACTS="${WORK_DIR}/kernel-artifacts"

log() { echo -e "\033[0;32m[ROOTFS]\033[0m $*"; }
err() { echo -e "\033[0;31m[ROOTFS ERROR]\033[0m $*" >&2; exit 1; }

mkdir -p "${ROOTFS}"

# ── Download ubuntu-base ─────────────────────────────────────
if [[ ! -f "${TARBALL}" ]]; then
  log "Downloading ubuntu-base from ${UBUNTU_BASE_URL} ..."
  wget -c -O "${TARBALL}" "${UBUNTU_BASE_URL}" || err "Failed to download ubuntu-base"
fi

# ── Extract ───────────────────────────────────────────────────
if [[ ! -f "${ROOTFS}/bin/bash" ]]; then
  log "Extracting ubuntu-base into rootfs..."
  tar -xzf "${TARBALL}" -C "${ROOTFS}"
fi

# ── QEMU static binary for chroot ────────────────────────────
log "Copying qemu-aarch64-static for chroot execution..."
cp /usr/bin/qemu-aarch64-static "${ROOTFS}/usr/bin/"

# ── Bind mounts helper ───────────────────────────────────────
mount_chroot() {
  log "Mounting virtual filesystems..."
  mount -t proc  none "${ROOTFS}/proc"      2>/dev/null || true
  mount -t sysfs none "${ROOTFS}/sys"       2>/dev/null || true
  mount --bind  /dev  "${ROOTFS}/dev"       2>/dev/null || true
  mount -t devpts devpts "${ROOTFS}/dev/pts" -o gid=5,mode=620 2>/dev/null || true
  mount --bind  /run  "${ROOTFS}/run"       2>/dev/null || true
}

umount_chroot() {
  log "Unmounting virtual filesystems..."
  umount -lf "${ROOTFS}/run"      2>/dev/null || true
  umount -lf "${ROOTFS}/dev/pts"  2>/dev/null || true
  umount -lf "${ROOTFS}/dev"      2>/dev/null || true
  umount -lf "${ROOTFS}/sys"      2>/dev/null || true
  umount -lf "${ROOTFS}/proc"     2>/dev/null || true
}

trap 'umount_chroot' EXIT

# ── Prepare chroot environment ────────────────────────────────
log "Preparing chroot environment..."
cat > "${ROOTFS}/etc/resolv.conf" <<'EOF'
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF

# APT sources for ubuntu 26.04
# Codename for 26.04 is not yet finalized — using snapshot base
# We'll use noble (24.04) as fallback if 26.04 isn't in repos yet,
# but the ubuntu-base itself provides the correct binary base.
# Detect codename from the rootfs
CODENAME=$(chroot "${ROOTFS}" /bin/sh -c 'cat /etc/os-release 2>/dev/null | grep VERSION_CODENAME | cut -d= -f2' 2>/dev/null || echo "noble")
log "Detected codename: ${CODENAME}"

cat > "${ROOTFS}/etc/apt/sources.list" <<EOF
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME} main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME}-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME}-security main restricted universe multiverse
EOF

mount_chroot

# ── Copy chroot setup script ───────────────────────────────────
cp "${SCRIPTS_DIR}/chroot-setup.sh" "${ROOTFS}/chroot-setup.sh"
chmod +x "${ROOTFS}/chroot-setup.sh"

# ── Run chroot setup ──────────────────────────────────────────
log "Running chroot setup (installing packages)..."
log "This may take 5-20 minutes depending on connection speed..."

chroot "${ROOTFS}" /bin/bash /chroot-setup.sh
rm -f "${ROOTFS}/chroot-setup.sh"

# ── Install kernel modules into rootfs ───────────────────────
if [[ -d "${KERNEL_ARTIFACTS}/lib/modules" ]]; then
  log "Installing kernel modules into rootfs..."
  cp -r "${KERNEL_ARTIFACTS}/lib/modules" "${ROOTFS}/lib/"
else
  log "Warning: No kernel modules found at ${KERNEL_ARTIFACTS}/lib/modules"
  log "Run the kernel step first, or modules can be installed later"
fi

# ── Apply overlay files ───────────────────────────────────────
log "Applying overlay files..."
cp -r "${OVERLAY_DIR}/." "${ROOTFS}/"

# Fix permissions
chmod 755 "${ROOTFS}/usr/local/bin/"* 2>/dev/null || true
chmod 644 "${ROOTFS}/etc/os-release" 2>/dev/null || true

# ── Clean up ─────────────────────────────────────────────────
log "Cleaning up rootfs..."
rm -f "${ROOTFS}/usr/bin/qemu-aarch64-static"
rm -f "${ROOTFS}/etc/resolv.conf"
# Create symlink (systemd-resolved manages it at runtime)
ln -sf /run/systemd/resolve/stub-resolv.conf "${ROOTFS}/etc/resolv.conf" 2>/dev/null || true

# Clean apt cache
chroot "${ROOTFS}" apt-get clean 2>/dev/null || true
rm -rf "${ROOTFS}/var/lib/apt/lists/"*
rm -rf "${ROOTFS}/var/cache/apt/"*
rm -rf "${ROOTFS}/tmp/"*
rm -rf "${ROOTFS}/var/tmp/"*

log "Rootfs setup complete!"
log "Size: $(du -sh "${ROOTFS}" | cut -f1)"
