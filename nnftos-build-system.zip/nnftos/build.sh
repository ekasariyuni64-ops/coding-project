#!/usr/bin/env bash
# ============================================================
#  No Name For This OS — Main Build Orchestrator
#  Target: aarch64 / arm64
#  Bootable ISO for QEMU virt machine
# ============================================================
set -euo pipefail

# ── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

log()  { echo -e "${GREEN}[BUILD]${RESET} $*"; }
warn() { echo -e "${YELLOW}[WARN] ${RESET} $*"; }
err()  { echo -e "${RED}[ERR]  ${RESET} $*" >&2; exit 1; }
step() { echo -e "\n${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"; \
         echo -e "${BOLD}${CYAN}  STEP: $*${RESET}"; \
         echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}\n"; }

# ── Paths ────────────────────────────────────────────────────
export BUILD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export WORK_DIR="${BUILD_DIR}/work"
export OUT_DIR="${BUILD_DIR}/output"
export KERNEL_SRC="${WORK_DIR}/kernel"
export ROOTFS_DIR="${WORK_DIR}/rootfs"
export ISO_STAGE="${WORK_DIR}/iso-stage"
export SCRIPTS_DIR="${BUILD_DIR}/scripts"
export OVERLAY_DIR="${BUILD_DIR}/overlay"
export CONFIGS_DIR="${BUILD_DIR}/configs"

# ── Versions / URLs ──────────────────────────────────────────
export UBUNTU_BASE_URL="https://cdimage.ubuntu.com/ubuntu-base/releases/26.04/snapshot-4/ubuntu-base-26.04-snapshot4-base-arm64.tar.gz"
export KERNEL_URL="https://git.kernel.org/torvalds/t/linux-7.0-rc3.tar.gz"
export ARCH="arm64"
export CROSS_COMPILE="aarch64-linux-gnu-"
export OS_NAME="No Name For This OS"
export OS_VERSION="0.1.0"
export OS_CODENAME="nameless"

# ── Parse flags ──────────────────────────────────────────────
STEPS_TO_RUN=()
SKIP_KERNEL=0
SKIP_ROOTFS=0
CLEAN_BUILD=0

usage() {
  cat <<EOF
Usage: $0 [options] [steps...]

Steps (run all if none specified):
  deps      Install host build dependencies
  kernel    Download & build Linux kernel
  rootfs    Setup rootfs from ubuntu-base
  squash    Pack rootfs into squashfs
  iso       Assemble final bootable ISO

Options:
  --skip-kernel   Reuse existing compiled kernel
  --skip-rootfs   Reuse existing rootfs
  --clean         Start from scratch (removes work/)
  --help          Show this help

Example:
  $0                    # full build
  $0 --skip-kernel iso  # rebuild ISO only
  $0 kernel             # only build kernel
EOF
  exit 0
}

for arg in "$@"; do
  case "$arg" in
    --skip-kernel) SKIP_KERNEL=1 ;;
    --skip-rootfs) SKIP_ROOTFS=1 ;;
    --clean) CLEAN_BUILD=1 ;;
    --help|-h) usage ;;
    deps|kernel|rootfs|squash|iso) STEPS_TO_RUN+=("$arg") ;;
    *) err "Unknown argument: $arg" ;;
  esac
done

[[ ${#STEPS_TO_RUN[@]} -eq 0 ]] && STEPS_TO_RUN=(deps kernel rootfs squash iso)

# ── Sanity checks ────────────────────────────────────────────
[[ "$(id -u)" -eq 0 ]] || err "Must run as root (needed for chroot & mknod)"
[[ "$(uname -m)" == "x86_64" ]] || warn "Detected non-x86_64 host — cross-compile may behave differently"

# ── Clean ────────────────────────────────────────────────────
if [[ $CLEAN_BUILD -eq 1 ]]; then
  warn "Clean build requested — removing ${WORK_DIR}"
  rm -rf "${WORK_DIR}"
fi

mkdir -p "${WORK_DIR}" "${OUT_DIR}"

# ── Run steps ────────────────────────────────────────────────
run_step() {
  local name="$1"
  local script="${SCRIPTS_DIR}/${name}.sh"
  [[ -f "$script" ]] || err "Step script not found: $script"
  step "$name"
  bash "$script"
}

for step_name in "${STEPS_TO_RUN[@]}"; do
  case "$step_name" in
    deps)   run_step "01-deps"   ;;
    kernel) [[ $SKIP_KERNEL -eq 1 ]] && { log "Skipping kernel build"; continue; }
            run_step "02-kernel" ;;
    rootfs) [[ $SKIP_ROOTFS -eq 1 ]] && { log "Skipping rootfs setup"; continue; }
            run_step "03-rootfs" ;;
    squash) run_step "04-squash" ;;
    iso)    run_step "05-iso"    ;;
  esac
done

echo -e "\n${BOLD}${GREEN}╔══════════════════════════════════════════╗"
echo -e "║   Build Complete!                        ║"
echo -e "║   ISO: output/nnftos-${OS_VERSION}-arm64.iso   ║"
echo -e "╚══════════════════════════════════════════╝${RESET}\n"

echo -e "${CYAN}Test with QEMU:${RESET}"
cat <<'EOF'
  # Install QEMU EFI firmware first:
  #   sudo apt install qemu-efi-aarch64 qemu-system-aarch64

  qemu-system-aarch64 \
    -machine virt \
    -cpu cortex-a57 \
    -m 2G \
    -smp 2 \
    -bios /usr/share/qemu-efi-aarch64/QEMU_EFI.fd \
    -drive file=output/nnftos-0.1.0-arm64.iso,format=raw,if=virtio,readonly=on \
    -drive file=output/nnftos-disk.qcow2,format=qcow2,if=virtio \
    -netdev user,id=net0 \
    -device virtio-net-device,netdev=net0 \
    -nographic \
    -serial stdio

  # Create empty target disk first (if installing):
  #   qemu-img create -f qcow2 output/nnftos-disk.qcow2 10G
EOF
